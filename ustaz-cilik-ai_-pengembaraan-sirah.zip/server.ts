import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { checkSirahScope, getOutOfScopeResponse, findLocalSirahAnswer } from './src/logic/chatGuard';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const isValidApiKey = Boolean(
  process.env.GEMINI_API_KEY &&
  process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY' &&
  process.env.GEMINI_API_KEY.trim() !== ''
);

// Inisialisasi Google GenAI (Server-side sahaja)
let ai: GoogleGenAI | null = null;
if (isValidApiKey) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `
Anda ialah "Ustaz Cilik AI", maskot dan teman pembelajaran Pendidikan Islam Tahun 3 (murid sekolah rendah Malaysia, berumur sekitar 9 tahun).
Misi anda adalah mendidik murid tentang Sirah Nabi Muhammad SAW dengan penuh gembira, sopan dan santun.

PERATURAN UTAMA:
1. BAHASA: Gunakan Bahasa Melayu Malaysia yang sopan, mesra, mudah dan ceria ("Assalamualaikum adik!", "Hebatnya adik!", "Jom kita terokai!").
2. PANJANG JAWAPAN: Maksimum 2 hingga 4 ayat ringkas. Satu atau dua idea utama sahaja pada satu masa. Jangan tulis esei panjang.
3. ADAB ISLAM: Hormati Nabi Muhammad SAW dengan meletakkan "SAW" atau "Shallallahu 'Alaihi Wasallam", para sahabat dengan "RA", para malaikat dengan "AS". Jangan reka-reka ayat Al-Quran atau hadis palsu.
4. TOPIK UTAMA: Fokus utama ialah peristiwa Wahyu Pertama di Gua Hira' (Malaikat Jibril AS, perintah Iqra', Surah Al-'Alaq 1-5, usia 40 tahun, malam 17 Ramadan, pengajaran membaca dan menuntut ilmu).
5. SKOP SIRAH: Murid juga boleh bertanya tentang Sirah Nabi Muhammad SAW yang lain (kehidupan awal, akhlak Baginda, hijrah ke Madinah, dakwah di Makkah).
6. KELUAR SKOP: Jika murid bertanya tentang topik di luar Sirah (seperti matematik, sains moden, permainan video, kartun biasa, dll.), jawab dengan sopan:
"Wah, soalan yang menarik, adik! Saya Ustaz Cilik, teman pengembaraan Sirah kita. Saya boleh bantu adik mengenali kisah hidup Nabi Muhammad SAW. Jom kita terokai Sirah bersama-sama!"
7. SOALAN SUSULAN: Sentiasa akhiri penerangan dengan satu soalan susulan atau ajakan yang memberi semangat kepada murid.
`;

// API Laluan Chatbot Ustaz Cilik
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string' || message.trim() === '') {
      return res.status(400).json({ error: 'Mesej tidak boleh kosong.' });
    }

    const trimmedMessage = message.trim();

    // 1. Semak skop soalan menggunakan pelindung Sirah tempatan
    const scopeCheck = checkSirahScope(trimmedMessage);
    if (!scopeCheck.isInScope) {
      const outOfScopeData = getOutOfScopeResponse();
      return res.json({
        reply: outOfScopeData.reply,
        isOutOfScope: true,
        expression: outOfScopeData.expression,
        suggestions: outOfScopeData.suggestions,
        source: 'scope_guard',
      });
    }

    // 2. Semak jawapan tempatan yang tepat (pantas)
    const localAnswer = findLocalSirahAnswer(trimmedMessage);

    // 3. Jika Gemini API tersedia dengan kunci sah, hubungi model gemini-3.8-flash dengan timeout
    if (ai && isValidApiKey) {
      try {
        const contents = [];
        if (Array.isArray(history) && history.length > 0) {
          for (const item of history.slice(-6)) {
            if (item.sender === 'user') {
              contents.push({ role: 'user', parts: [{ text: item.text }] });
            } else if (item.sender === 'ustaz') {
              contents.push({ role: 'model', parts: [{ text: item.text }] });
            }
          }
        }
        contents.push({ role: 'user', parts: [{ text: trimmedMessage }] });

        const geminiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
            topP: 0.9,
          },
        });

        const timeoutPromise = new Promise<null>((_, reject) =>
          setTimeout(() => reject(new Error('AI request timed out')), 4000)
        );

        const response: any = await Promise.race([geminiPromise, timeoutPromise]);

        const generatedText = response?.text || '';
        if (generatedText) {
          return res.json({
            reply: generatedText,
            isOutOfScope: false,
            expression: 'explaining',
            suggestions: [
              'Apakah maksud wahyu?',
              'Kenapa Nabi SAW ke Gua Hira\'?',
              'Berapa usia Nabi masa wahyu pertama?',
              'Apa pengajaran untuk kita?',
            ],
            source: 'gemini_ai',
          });
        }
      } catch (geminiError) {
        console.warn('Gemini API call notice, falling back to local Sirah knowledge:', geminiError);
      }
    }

    // 4. Jika AI tidak dihubungi atau gagal, gunakan jawapan tempatan berpandukan infografik
    if (localAnswer) {
      const fullReply = localAnswer.followUp
        ? `${localAnswer.reply}\n\n${localAnswer.followUp}`
        : localAnswer.reply;

      return res.json({
        reply: fullReply,
        isOutOfScope: false,
        expression: localAnswer.expression,
        suggestions: [
          'Apakah maksud wahyu?',
          'Di manakah Gua Hira\'?',
          'Siapakah Malaikat Jibril AS?',
          'Apakah 3 pengajaran wahyu pertama?',
        ],
        source: 'local_verified',
      });
    }

    // Jawapan umum berpandukan Sirah
    return res.json({
      reply:
        'Masya-Allah, soalan yang sangat baik adik! Peristiwa Sirah Nabi Muhammad SAW penuh dengan hikmah dan teladan mulia. Untuk mendalami kisah ini, jom kita lihat infografik Gua Hira\' atau cuba kuiz Sirah bersama Ustaz Cilik!',
      isOutOfScope: false,
      expression: 'welcoming',
      suggestions: [
        'Ceritakan tentang Gua Hira\'',
        'Apakah ayat pertama diturunkan?',
        'Siapakah isteri tercinta Nabi SAW?',
      ],
      source: 'local_verified',
    });
  } catch (error) {
    console.error('Chat endpoint error:', error);
    return res.status(500).json({
      reply:
        'Maafkan Ustaz Cilik, ada sedikit gangguan teknikal. Jom kita cuba sekali lagi atau pilih soalan cadangan di bawah!',
      isOutOfScope: false,
      expression: 'helper',
      suggestions: ['Apakah maksud wahyu?', 'Di manakah Gua Hira\'?'],
    });
  }
});

// Semakan status kesihatan API
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    appName: 'Ustaz Cilik AI: Pengembaraan Sirah',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Pemasangan Vite middleware dalam pembangunan atau pelayan statik dalam pengeluaran
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Ustaz Cilik AI] Pelayan berjalan di http://0.0.0.0:${PORT}`);
  });
}

startServer();
