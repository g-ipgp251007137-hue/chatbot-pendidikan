/**
 * Data teras Sirah Wahyu Pertama dan Topik Sirah Nabi Muhammad SAW
 * Berpandukan sukatan Pendidikan Islam Tahun 3 (KSSR Semakan) dan Infografik Wahyu Pertama.
 */

export interface LearningObjective {
  id: string;
  code: string;
  title: string;
  description: string;
  status: 'belum_mula' | 'sedang_belajar' | 'dikuasai';
}

export interface InfographicSection {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  summary: string;
  points: string[];
  explanation: string;
  audioNarration: string;
  highlightText: string;
}

export interface QuizQuestion {
  id: string;
  objectiveId: string;
  type: 'multiple_choice' | 'true_false' | 'matching';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint: string;
  topic: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'misi' | 'pembacaan' | 'kuiz' | 'soalan';
  unlockedAt?: string;
}

export interface SirahTopic {
  id: string;
  title: string;
  period: string;
  description: string;
  status: 'terbuka' | 'terkunci';
  sampleQuestions: string[];
  keyFact: string;
}

export const INITIAL_OBJECTIVES: LearningObjective[] = [
  {
    id: 'obj_1',
    code: 'OP1',
    title: 'Maksud Wahyu',
    description: 'Menyatakan maksud wahyu dengan jelas dan tepat.',
    status: 'belum_mula',
  },
  {
    id: 'obj_2',
    code: 'OP2',
    title: 'Peristiwa Wahyu Pertama',
    description: 'Menjelaskan peristiwa penurunan wahyu pertama (Iqra\') oleh Malaikat Jibril AS.',
    status: 'belum_mula',
  },
  {
    id: 'obj_3',
    code: 'OP3',
    title: 'Tempat Peristiwa (Gua Hira\')',
    description: 'Mengenal pasti Gua Hira\' di Jabal Nur sebagai tempat berlakunya wahyu pertama.',
    status: 'belum_mula',
  },
  {
    id: 'obj_4',
    code: 'OP4',
    title: 'Pengajaran Peristiwa',
    description: 'Menyatakan sekurang-kurangnya tiga pengajaran penting daripada peristiwa wahyu pertama.',
    status: 'belum_mula',
  },
];

export const INITIAL_INFOGRAPHIC: InfographicSection[] = [
  {
    id: 'info_maksud',
    title: '1. Maksud Wahyu',
    subtitle: 'Kalam Suci daripada Allah SWT',
    iconName: 'BookOpen',
    summary: 'Kalam Allah SWT yang disampaikan kepada para nabi dan rasul melalui perantaraan Malaikat Jibril AS.',
    points: [
      'Wahyu ialah kata-kata atau perintah daripada Allah SWT.',
      'Disampaikan secara khusus kepada nabi dan rasul.',
      'Malaikat Jibril AS ialah utusan yang membawa wahyu.',
    ],
    explanation: 'Adik-adik, wahyu ialah ajaran suci daripada Allah SWT yang mengajar manusia mengenal Tuhan, berakhlak mulia dan hidup bahagia di dunia dan akhirat.',
    audioNarration: 'Maksud wahyu ialah kalam Allah SWT yang diturunkan kepada para nabi dan rasul melalui perantaraan Malaikat Jibril Alaihissalam.',
    highlightText: 'Kalam Allah SWT kepada Para Nabi',
  },
  {
    id: 'info_tempat_masa',
    title: '2. Tempat & Masa Peristiwa',
    subtitle: 'Gua Hira\' & Malam 17 Ramadan',
    iconName: 'Mountain',
    summary: 'Berlaku di Gua Hira\', Jabal Nur, Makkah pada malam 17 Ramadan ketika Nabi SAW berusia 40 tahun.',
    points: [
      'Tempat: Gua Hira\' yang terletak di puncak bukit Jabal Nur.',
      'Masa: Malam Isnin, 17 Ramadan.',
      'Usia Nabi Muhammad SAW: Genap 40 tahun.',
      'Tujuan Baginda di Gua Hira\': Bertahannuth (beribadah dan berfikir tentang kebesaran Allah).',
    ],
    explanation: 'Nabi Muhammad SAW suka menyendiri di Gua Hira\' untuk beribadah dan menjauhkan diri daripada perbuatan buruk masyarakat jahiliah pada masa itu.',
    audioNarration: 'Peristiwa penurunan wahyu pertama berlaku di Gua Hira\', Jabal Nur, pada malam 17 Ramadan ketika Nabi Muhammad SAW berusia 40 tahun.',
    highlightText: 'Gua Hira\', Jabal Nur — Usia 40 Tahun',
  },
  {
    id: 'info_peristiwa',
    title: '3. Detik Penurunan Wahyu',
    subtitle: 'Pertemuan dengan Malaikat Jibril AS',
    iconName: 'Sparkles',
    summary: 'Malaikat Jibril AS memeluk Nabi Muhammad SAW sebanyak tiga kali sambil meminta Baginda membaca: "Iqra\'!"',
    points: [
      'Malaikat Jibril AS datang dalam bentuk yang sangat agung.',
      'Jibril berkata: "Iqra\'!" (Bacalah!).',
      'Nabi SAW menjawab dengan jujur: "Aku tidak tahu membaca."',
      'Jibril memeluk Nabi SAW dengan erat sebanyak 3 kali.',
      'Kemudian dibacakan 5 ayat pertama Surah Al-\'Alaq.',
    ],
    explanation: 'Baginda berasa sangat gementar lalu pulang ke rumah menemui isteri tercinta, Saidatina Khadijah RA, dan meminta diselimutkan: "Zammiluni, zammiluni!" (Selimutkanlah daku!).',
    audioNarration: 'Malaikat Jibril Alaihissalam memeluk erat Nabi Muhammad SAW sebanyak tiga kali lalu menyampaikan perintah membaca: Iqra\'!',
    highlightText: 'Iqra\'! — Bacalah dengan nama Tuhanmu',
  },
  {
    id: 'info_ayat',
    title: '4. Ayat Wahyu Pertama',
    subtitle: 'Surah Al-\'Alaq (Ayat 1 hingga 5)',
    iconName: 'Scroll',
    summary: 'Lima ayat terawal Surah Al-\'Alaq yang memerintahkan manusia menuntut ilmu dan membaca.',
    points: [
      'Ayat 1: Bacalah dengan nama Tuhanmu yang menciptakan.',
      'Ayat 2: Dia menciptakan manusia daripada segumpal darah.',
      'Ayat 3: Bacalah, dan Tuhanmulah Yang Maha Pemurah.',
      'Ayat 4: Yang mengajar manusia dengan pena (kalam).',
      'Ayat 5: Mengajar manusia apa yang tidak diketahuinya.',
    ],
    explanation: 'Ayat-ayat ini membuktikan bahawa Islam amat mementingkan ilmu pengetahuan, membaca dan menulis demi membina peribadi yang beriman.',
    audioNarration: 'Wahyu pertama yang diturunkan ialah lima ayat awal daripada Surah Al-\'Alaq yang mengajar kita kepentingan membaca dan menuntut ilmu.',
    highlightText: 'Surah Al-\'Alaq: Ayat 1 - 5',
  },
  {
    id: 'info_pengajaran',
    title: '5. Tiga Pengajaran Utama',
    subtitle: 'Amalan untuk Kehidupan Seharian Murid',
    iconName: 'HeartHandshake',
    summary: 'Tiga pengajaran utama: Wajib menuntut ilmu, gigih berusaha dan bersabar, serta beriman teguh kepada Allah SWT.',
    points: [
      '1. Kepentingan Ilmu: Rajin membaca dan belajar di sekolah dan di rumah.',
      '2. Bersabar & Gigih: Tidak mudah berputus asa apabila menghadapi cabaran pelajaran.',
      '3. Keimanan kepada Allah: Sentiasa memulakan setiap amalan dengan menyebut nama Allah SWT (Bismillah).',
    ],
    explanation: 'Sebagai murid Tahun 3, adik-adik perlu mencontohi Nabi Muhammad SAW dengan sentiasa bersemangat menimba ilmu dan bercakap benar.',
    audioNarration: 'Tiga pengajaran penting ialah: pertama, kewajipan menuntut ilmu; kedua, sifat sabar dan gigih; ketiga, sentiasa mengingati Allah dalam setiap perkara.',
    highlightText: 'Ilmu • Kesabaran • Keimanan',
  },
];

export const INITIAL_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    objectiveId: 'obj_1',
    type: 'multiple_choice',
    question: 'Apakah maksud wahyu?',
    options: [
      'Kalam Allah SWT yang diturunkan kepada para nabi dan rasul.',
      'Cerita dongeng zaman dahulu.',
      'Surat khabar yang dibaca setiap pagi.',
      'Buku cerita yang ditulis oleh manusia.',
    ],
    correctIndex: 0,
    explanation: 'Tepat sekali! Wahyu ialah kalam suci Allah SWT yang disampaikan kepada para nabi dan rasul melalui Malaikat Jibril AS.',
    hint: 'Fikirkan tentang kalam suci yang datang daripada Allah SWT.',
    topic: 'Wahyu Pertama',
  },
  {
    id: 'q2',
    objectiveId: 'obj_3',
    type: 'multiple_choice',
    question: 'Di manakah Nabi Muhammad SAW menerima wahyu pertama?',
    options: [
      'Gua Thur',
      'Gua Hira\' di Jabal Nur',
      'Masjidil Haram',
      'Kota Madinah',
    ],
    correctIndex: 1,
    explanation: 'Bagus, adik! Peristiwa wahyu pertama berlaku di Gua Hira\' yang terletak di bukit Jabal Nur, berhampiran Makkah.',
    hint: 'Gua ini terletak di bukit Jabal Nur.',
    topic: 'Wahyu Pertama',
  },
  {
    id: 'q3',
    objectiveId: 'obj_2',
    type: 'multiple_choice',
    question: 'Siapakah malaikat yang diutus oleh Allah SWT untuk menyampaikan wahyu pertama?',
    options: [
      'Malaikat Mikail AS',
      'Malaikat Israfil AS',
      'Malaikat Jibril AS',
      'Malaikat Malik AS',
    ],
    correctIndex: 2,
    explanation: 'Hebat! Malaikat Jibril AS ialah utusan Allah SWT yang bertanggungjawab menyampaikan wahyu kepada para rasul.',
    hint: 'Malaikat ini terkenal dengan gelaran pembawa wahyu.',
    topic: 'Wahyu Pertama',
  },
  {
    id: 'q4',
    objectiveId: 'obj_2',
    type: 'true_false',
    question: 'Wahyu pertama yang diturunkan kepada Nabi Muhammad SAW ialah Surah Al-Fatihah.',
    options: [
      'Benar',
      'Palsu (Salah)',
    ],
    correctIndex: 1,
    explanation: 'Tepat! Wahyu pertama ialah Surah Al-\'Alaq ayat 1 hingga 5, bukan Surah Al-Fatihah.',
    hint: 'Surah pertama bermula dengan perkataan "Iqra\'" (Bacalah).',
    topic: 'Wahyu Pertama',
  },
  {
    id: 'q5',
    objectiveId: 'obj_2',
    type: 'multiple_choice',
    question: 'Berapakah usia Nabi Muhammad SAW ketika menerima wahyu pertama?',
    options: [
      '25 tahun',
      '30 tahun',
      '40 tahun',
      '63 tahun',
    ],
    correctIndex: 2,
    explanation: 'Bijak! Nabi Muhammad SAW diangkat menjadi Rasul ketika Baginda genap berusia 40 tahun.',
    hint: 'Usia matang Baginda ketika berkhalwat di Gua Hira\'.',
    topic: 'Wahyu Pertama',
  },
  {
    id: 'q6',
    objectiveId: 'obj_4',
    type: 'multiple_choice',
    question: 'Antara berikut, yang manakah pengajaran utama daripada peristiwa wahyu pertama?',
    options: [
      'Kewajipan rajin menuntut ilmu dan membaca.',
      'Hanya bermain sepanjang hari tanpa belajar.',
      'Tidak perlu mendengar nasihat guru dan ibu bapa.',
      'Tidur lewat setiap malam.',
    ],
    correctIndex: 0,
    explanation: 'Alhamdulillah betul! Kalimah "Iqra\'" mengajar kita agar sentiasa rajin membaca dan menuntut ilmu yang berfaedah.',
    hint: 'Perkataan "Iqra\'" bermaksud "Bacalah!".',
    topic: 'Wahyu Pertama',
  },
];

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge_penjelajah',
    title: 'Penjelajah Sirah',
    description: 'Memulakan pengembaraan bersama Ustaz Cilik ke Portal Gua Hira\'.',
    icon: 'Compass',
    category: 'misi',
  },
  {
    id: 'badge_pencari_ilmu',
    title: 'Pencari Ilmu',
    description: 'Membaca dan meneroka semua 5 bahagian infografik Wahyu Pertama.',
    icon: 'BookOpen',
    category: 'pembacaan',
  },
  {
    id: 'badge_bintang_wahyu',
    title: 'Bintang Wahyu Pertama',
    description: 'Berjaya menjawab soalan peristiwa Wahyu Pertama dengan betul.',
    icon: 'Sparkles',
    category: 'kuiz',
  },
  {
    id: 'badge_juara_kuiz',
    title: 'Juara Kuiz Sirah',
    description: 'Mencapai skor cemerlang 80% ke atas dalam kuiz pemahaman Sirah.',
    icon: 'Trophy',
    category: 'kuiz',
  },
  {
    id: 'badge_peneroka_berani',
    title: 'Peneroka Berani',
    description: 'Mengajukan soalan penuh rasa ingin tahu kepada Ustaz Cilik AI.',
    icon: 'MessageCircleQuestion',
    category: 'soalan',
  },
];

export const SIRAH_TOPICS: SirahTopic[] = [
  {
    id: 'sebelum_wahyu',
    title: '1. Sebelum Wahyu Pertama',
    period: 'Kelahiran hingga Usia 40 Tahun',
    description: 'Kisah zaman kanak-kanak Baginda, peristiwa pembelahan dada, berniaga ke Syam, dan perkahwinan dengan Saidatina Khadijah RA.',
    status: 'terbuka',
    sampleQuestions: [
      'Bilakah Nabi Muhammad SAW dilahirkan?',
      'Siapakah nama ibu dan bapa Nabi SAW?',
      'Mengapa Nabi SAW digelar Al-Amin?',
      'Apakah pekerjaan Nabi SAW semasa remaja?',
    ],
    keyFact: 'Nabi Muhammad SAW terkenal dengan gelaran Al-Amin kerana sifat Baginda yang amat jujur dan amanah.',
  },
  {
    id: 'wahyu_pertama',
    title: '2. Misi Utama: Wahyu Pertama',
    period: 'Malam 17 Ramadan (Usia 40 Tahun)',
    description: 'Peristiwa agung penurunan wahyu pertama di Gua Hira\', pertemuan dengan Malaikat Jibril AS, dan Surah Al-\'Alaq.',
    status: 'terbuka',
    sampleQuestions: [
      'Apakah maksud wahyu?',
      'Di manakah Gua Hira\' terletak?',
      'Apakah kalimah pertama yang diucapkan Malaikat Jibril?',
      'Apakah pengajaran daripada peristiwa wahyu pertama?',
    ],
    keyFact: 'Wahyu pertama membawa perintah "Iqra\'" (Bacalah) yang mengangkat martabat ilmu dalam Islam.',
  },
  {
    id: 'dakwah_makkah',
    title: '3. Dakwah di Makkah',
    period: '13 Tahun di Makkah',
    description: 'Dakwah secara rahsia (sirriyyah) di rumah Al-Arqam dan dakwah secara terang-terangan (jahriyyah) di Bukit Safa.',
    status: 'terbuka',
    sampleQuestions: [
      'Berapa lamakah dakwah secara rahsia dijalankan?',
      'Siapakah golongan terawal memeluk Islam (As-Sabiqun al-Awwalun)?',
      'Apakah ujian yang dihadapi oleh Bilal bin Rabah RA?',
      'Di manakah pusat dakwah rahsia Nabi SAW?',
    ],
    keyFact: 'Saidatina Khadijah RA ialah wanita pertama yang beriman dan menyokong penuh dakwah Baginda.',
  },
  {
    id: 'hijrah_madinah',
    title: '4. Hijrah ke Madinah',
    period: 'Tahun 622 Masihi',
    description: 'Perjalanan bersejarah Nabi SAW bersama Sayyidina Abu Bakar As-Siddiq RA berhijrah dari Makkah ke Madinah.',
    status: 'terbuka',
    sampleQuestions: [
      'Mengapakah Nabi Muhammad SAW berhijrah ke Madinah?',
      'Siapakah sahabat yang menemani Nabi semasa di Gua Thur?',
      'Apakah masjid pertama yang dibina semasa hijrah?',
      'Apakah gelaran bagi penduduk Madinah yang menyambut orang Makkah?',
    ],
    keyFact: 'Kaum Muhajirin (dari Makkah) dan Kaum Ansar (penduduk Madinah) dipersaudarakan dengan penuh kasih sayang.',
  },
  {
    id: 'peristiwa_penting',
    title: '5. Peristiwa Penting Sirah',
    period: 'Zaman Kenabian',
    description: 'Peristiwa Isra\' dan Mi\'raj (hadiah solat 5 waktu), Perang Badar, dan Pembukaan Kota Makkah (Fath Makkah).',
    status: 'terbuka',
    sampleQuestions: [
      'Apakah mukjizat agung dalam peristiwa Isra\' dan Mi\'raj?',
      'Berapa rakaat solat yang difardukan kepada umat Islam?',
      'Apakah yang berlaku semasa Pembukaan Kota Makkah (Fath Makkah)?',
      'Apakah sifat pemaaf Nabi SAW terhadap musuh?',
    ],
    keyFact: 'Solat fardu lima waktu adalah anugerah teragung yang diterima secara langsung dalam peristiwa Mi\'raj.',
  },
  {
    id: 'akhlak_pengajaran',
    title: '6. Akhlak & Teladan Rasulullah',
    period: 'Sepanjang Hayat',
    description: 'Empat sifat wajib bagi rasul: Siddiq (Benar), Amanah (Jujur), Tabligh (Menyampaikan), Fatonah (Bijaksana) dan Rahmatan lil Alamin.',
    status: 'terbuka',
    sampleQuestions: [
      'Apakah empat sifat wajib bagi Nabi Muhammad SAW?',
      'Bagaimanakah cara kita menyayangi Rasulullah SAW?',
      'Bagaimanakah Nabi bergaul dengan kanak-kanak?',
      'Apakah maksud Rahmatan lil \'Alamin?',
    ],
    keyFact: 'Nabi Muhammad SAW diutuskan untuk menyempurnakan akhlak mulia bagi sekalian alam.',
  },
];
