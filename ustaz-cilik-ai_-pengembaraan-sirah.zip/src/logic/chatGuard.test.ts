import test from 'node:test';
import assert from 'node:assert/strict';
import {
  checkSirahScope,
  getOutOfScopeResponse,
  findLocalSirahAnswer,
} from './chatGuard';

test('checkSirahScope identifies in-scope Sirah questions', () => {
  const q1 = checkSirahScope('Apakah maksud wahyu pertama?');
  assert.equal(q1.isInScope, true);

  const q2 = checkSirahScope('Kenapa Nabi SAW pergi ke Gua Hira?');
  assert.equal(q2.isInScope, true);

  const q3 = checkSirahScope('Siapakah Malaikat Jibril yang datang jumpa Rasulullah?');
  assert.equal(q3.isInScope, true);

  const q4 = checkSirahScope('Apakah surah al-alaq?');
  assert.equal(q4.isInScope, true);
});

test('checkSirahScope detects out-of-scope non-Sirah questions', () => {
  const bad1 = checkSirahScope('Berapakah 2 + 2?');
  assert.equal(bad1.isInScope, false);

  const bad2 = checkSirahScope('Bagaimana nak main roblox dan minecraft?');
  assert.equal(bad2.isInScope, false);

  const bad3 = checkSirahScope('Boleh ajar formula matematik sifir 7?');
  assert.equal(bad3.isInScope, false);
});

test('getOutOfScopeResponse gives warm respectful redirection', () => {
  const resp = getOutOfScopeResponse();
  assert.ok(resp.reply.includes('Wah, soalan yang menarik, adik!'));
  assert.ok(resp.reply.includes('Ustaz Cilik'));
  assert.ok(resp.suggestions.length >= 3);
  assert.equal(resp.expression, 'helper');
});

test('findLocalSirahAnswer provides accurate verified answers for core Sirah events', () => {
  const ansWahyu = findLocalSirahAnswer('apa maksud wahyu');
  assert.ok(ansWahyu !== null);
  assert.ok(ansWahyu?.reply.toLowerCase().includes('kalam suci'));

  const ansGua = findLocalSirahAnswer('di mana gua hira');
  assert.ok(ansGua !== null);
  assert.ok(ansGua?.reply.includes('Jabal Nur'));
});
