import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateQuizScore,
  evaluateObjectiveMastery,
  evaluateBadges,
  getQuizFeedback,
} from './quizRules';
import { INITIAL_QUIZ_QUESTIONS, INITIAL_BADGES } from './sirahData';

test('calculateQuizScore calculates score and stars accurately', () => {
  // Perfect score
  const perfect = calculateQuizScore(5, 5);
  assert.equal(perfect.scorePercent, 100);
  assert.equal(perfect.stars, 3);
  assert.equal(perfect.passed, true);

  // Partial score (4/5 = 80%)
  const high = calculateQuizScore(5, 4);
  assert.equal(high.scorePercent, 80);
  assert.equal(high.stars, 3);
  assert.equal(high.passed, true);

  // Medium score (3/5 = 60%)
  const med = calculateQuizScore(5, 3);
  assert.equal(med.scorePercent, 60);
  assert.equal(med.stars, 2);
  assert.equal(med.passed, true);

  // Low score (1/5 = 20%)
  const low = calculateQuizScore(5, 1);
  assert.equal(low.scorePercent, 20);
  assert.equal(low.stars, 1);
  assert.equal(low.passed, false);

  // Zero / edge case
  const zero = calculateQuizScore(0, 0);
  assert.equal(zero.scorePercent, 0);
  assert.equal(zero.stars, 0);
});

test('evaluateObjectiveMastery tracks ASSURE learning objectives', () => {
  // q1 (obj_1), q2 (obj_3), q3 (obj_2)
  const userAnswers = {
    q1: 0, // correct (obj_1)
    q2: 1, // correct (obj_3)
    q3: 0, // wrong (obj_2 correct is 2)
  };

  const mastery = evaluateObjectiveMastery(INITIAL_QUIZ_QUESTIONS, userAnswers);

  assert.ok(mastery['obj_1'], 'obj_1 should be tracked');
  assert.equal(mastery['obj_1'].isMastered, true);
  assert.equal(mastery['obj_1'].correctQuestions, 1);

  assert.ok(mastery['obj_3'], 'obj_3 should be tracked');
  assert.equal(mastery['obj_3'].isMastered, true);

  // obj_2 had wrong answer
  assert.ok(mastery['obj_2']);
  assert.equal(mastery['obj_2'].correctQuestions, 0);
  assert.equal(mastery['obj_2'].isMastered, false);
});

test('evaluateBadges unlocks badges based on verifiable milestones', () => {
  const milestones = {
    hasExploredPortal: true,
    readSectionsCount: 5,
    totalSectionsCount: 5,
    quizCorrectCount: 4,
    quizScorePercent: 85,
    askedQuestionsCount: 2,
  };

  const { updatedBadges, newlyUnlocked } = evaluateBadges(INITIAL_BADGES, milestones);

  assert.equal(newlyUnlocked.length, 5, 'All 5 initial badges should unlock');
  assert.ok(updatedBadges.every((b) => b.unlockedAt !== undefined));
});

test('getQuizFeedback returns child-friendly encouraging messages', () => {
  const correctFeedback = getQuizFeedback(true);
  assert.equal(correctFeedback.expression, 'excited');
  assert.ok(correctFeedback.message.includes('Alhamdulillah'));

  const wrongFirstTry = getQuizFeedback(false, false);
  assert.equal(wrongFirstTry.expression, 'helper');

  const wrongSecondTry = getQuizFeedback(false, true);
  assert.equal(wrongSecondTry.expression, 'encouraging');
});
