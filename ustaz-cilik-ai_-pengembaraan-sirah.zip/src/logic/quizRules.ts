import { QuizQuestion, Badge } from './sirahData';

export interface ScoreSummary {
  total: number;
  correct: number;
  scorePercent: number;
  stars: number;
  passed: boolean;
  gradeLabel: string;
}

export function calculateQuizScore(total: number, correct: number): ScoreSummary {
  if (total <= 0) {
    return {
      total: 0,
      correct: 0,
      scorePercent: 0,
      stars: 0,
      passed: false,
      gradeLabel: 'Belum Menjawab',
    };
  }

  const clampedCorrect = Math.max(0, Math.min(correct, total));
  const scorePercent = Math.round((clampedCorrect / total) * 100);

  let stars = 1;
  let gradeLabel = 'Cuba Lagi, Adik Boleh!';
  let passed = false;

  if (scorePercent >= 80) {
    stars = 3;
    gradeLabel = 'Cemerlang! Mumtaz!';
    passed = true;
  } else if (scorePercent >= 60) {
    stars = 2;
    gradeLabel = 'Bagus! Jayyid Jiddan!';
    passed = true;
  } else if (scorePercent >= 40) {
    stars = 1;
    gradeLabel = 'Boleh Dipertingkatkan!';
    passed = false;
  }

  return {
    total,
    correct: clampedCorrect,
    scorePercent,
    stars,
    passed,
      gradeLabel,
  };
}

export interface ObjectiveMastery {
  objectiveId: string;
  totalQuestions: number;
  correctQuestions: number;
  percentage: number;
  isMastered: boolean;
}

export function evaluateObjectiveMastery(
  questions: QuizQuestion[],
  userAnswers: Record<string, number>
): Record<string, ObjectiveMastery> {
  const result: Record<string, { total: number; correct: number }> = {};

  for (const q of questions) {
    if (!result[q.objectiveId]) {
      result[q.objectiveId] = { total: 0, correct: 0 };
    }
    result[q.objectiveId].total += 1;

    const chosenIndex = userAnswers[q.id];
    if (chosenIndex !== undefined && chosenIndex === q.correctIndex) {
      result[q.objectiveId].correct += 1;
    }
  }

  const finalMap: Record<string, ObjectiveMastery> = {};
  for (const [objId, data] of Object.entries(result)) {
    const percentage = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;
    // Mastered if at least 70% of questions for this objective are correct
    const isMastered = percentage >= 70;
    finalMap[objId] = {
      objectiveId: objId,
      totalQuestions: data.total,
      correctQuestions: data.correct,
      percentage,
      isMastered,
    };
  }

  return finalMap;
}

export interface PlayerMilestones {
  hasExploredPortal: boolean;
  readSectionsCount: number;
  totalSectionsCount: number;
  quizCorrectCount: number;
  quizScorePercent: number;
  askedQuestionsCount: number;
}

export function evaluateBadges(
  allBadges: Badge[],
  milestones: PlayerMilestones
): { updatedBadges: Badge[]; newlyUnlocked: Badge[] } {
  const newlyUnlocked: Badge[] = [];
  const updatedBadges = allBadges.map((badge) => {
    if (badge.unlockedAt) {
      return badge; // already unlocked
    }

    let shouldUnlock = false;
    switch (badge.id) {
      case 'badge_penjelajah':
        shouldUnlock = milestones.hasExploredPortal;
        break;
      case 'badge_pencari_ilmu':
        shouldUnlock = milestones.readSectionsCount >= Math.min(5, milestones.totalSectionsCount);
        break;
      case 'badge_bintang_wahyu':
        shouldUnlock = milestones.quizCorrectCount >= 1;
        break;
      case 'badge_juara_kuiz':
        shouldUnlock = milestones.quizScorePercent >= 80;
        break;
      case 'badge_peneroka_berani':
        shouldUnlock = milestones.askedQuestionsCount >= 1;
        break;
      default:
        shouldUnlock = false;
    }

    if (shouldUnlock) {
      const unlockedBadge = { ...badge, unlockedAt: new Date().toISOString() };
      newlyUnlocked.push(unlockedBadge);
      return unlockedBadge;
    }

    return badge;
  });

  return { updatedBadges, newlyUnlocked };
}

export function getQuizFeedback(isCorrect: boolean, isSecondTry: boolean = false): {
  message: string;
  expression: 'excited' | 'helper' | 'encouraging';
} {
  if (isCorrect) {
    return {
      message: 'Alhamdulillah, betul adik! Bijak sungguh adik memahami Sirah Nabi!',
      expression: 'excited',
    };
  }

  if (isSecondTry) {
    return {
      message: 'Tidak mengapa, adik. Mari kita baca semula infografik dan cuba lagi sama-sama ya!',
      expression: 'encouraging',
    };
  }

  return {
    message: 'Hampir tepat! Jom kita fikir bersama-sama. Cuba tengok petunjuk di bawah.',
    expression: 'helper',
  };
}
