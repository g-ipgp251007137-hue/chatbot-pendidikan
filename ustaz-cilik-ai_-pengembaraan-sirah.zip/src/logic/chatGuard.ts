/**
 * Pengawal Skop Sirah & Enjin Respons Kanak-Kanak Ustaz Cilik AI
 * Memastikan perbualan tertumpu strictly kepada Sirah Nabi Muhammad SAW dan Wahyu Pertama.
 */

export interface ScopeCheckResult {
  isInScope: boolean;
  topic?: string;
  confidence: number;
}

// Topik yang DILARANG / DI LUAR SKOP (Matematik, sains, gaming moden, video games, hiburan, politik, dll.)
const OUT_OF_SCOPE_KEYWORDS = [
  'roblox',
  'minecraft',
  'free fire',
  'pubg',
  'mobile legends',
  'tiktok',
  'youtube viral',
  'matematik',
  'tambah nombor',
  'sifir',
  'formula kimia',
  'sains fizik',
  'gravity',
  'pokemon',
  'iron man',
  'anime',
  'spiderman',
  'kpop',
  'blackpink',
  'bts',
  'bitcoin',
  'crypto',
  'kereta lumba',
  'duit raya berapa ringgit',
];

// Topik Sirah Nabi Muhammad SAW yang SAH
const SIRAH_KEYWORDS = [
  'wahyu',
  'iqra',
  'gua hira',
  'jabal nur',
  'jabal nur',
  'jibril',
  'malaikat',
  'nabi',
  'rasulullah',
  'muhammad',
  'khadijah',
  'al-alaq',
  'alaq',
  'makkah',
  'madinah',
  'hijrah',
  'abu bakar',
  'ali',
  'usman',
  'umar',
  'siddiq',
  'amanah',
  'tabligh',
  'fatonah',
  'rahmatan',
  'badar',
  'uhud',
  'khandaq',
  'isra',
  'miraj',
  'solat',
  'fath makkah',
  'haji wida',
  'ramadan',
  'kalam',
  'tahannuth',
  'aminah',
  'abdullah',
  'abdul muttalib',
  'abu talib',
  'halimatus',
  'saadiah',
  'al-amin',
  'batu hajarul aswad',
  'zamzam',
  'tahun gajah',
  'surah',
  'al-quran',
  'hadis',
  'sunnah',
  'sahabat',
  'syiar',
  'dakwah',
  'islam',
  'iman',
];

export function checkSirahScope(query: string): ScopeCheckResult {
  const normalized = query.toLowerCase().trim();

  // 1. Semak soalan kosong
  if (!normalized) {
    return { isInScope: false, confidence: 1 };
  }

  // 2. Semak kata kunci luar skop
  for (const badKeyword of OUT_OF_SCOPE_KEYWORDS) {
    if (normalized.includes(badKeyword)) {
      return { isInScope: false, confidence: 0.95 };
    }
  }

  // 3. Semak formula matematik atau kiraan nombor (cth. "2+2", "5 x 10", "berapakah 2 + 2")
  if (/\d+\s*[\+\-\*\/xX÷=]\s*\d+/.test(normalized) || normalized.includes('tambah') || normalized.includes('tolak') || normalized.includes('darab') || normalized.includes('bahagi')) {
    return { isInScope: false, confidence: 0.99 };
  }

  // 4. Semak jika terdapat kata kunci Sirah
  for (const sirahWord of SIRAH_KEYWORDS) {
    if (normalized.includes(sirahWord)) {
      return { isInScope: true, topic: sirahWord, confidence: 0.9 };
    }
  }

  // 5. Semak kata tanya umum kanak-kanak mengenai cerita/peristiwa
  const generalInterestWords = ['siapa', 'kenapa', 'bagaimana', 'bila', 'tempat', 'kisah', 'cerita', 'baginda'];
  const hasQuestionWord = generalInterestWords.some((w) => normalized.includes(w));
  if (hasQuestionWord && (normalized.includes('dia') || normalized.includes('mereka') || normalized.includes('peristiwa'))) {
    return { isInScope: true, topic: 'umum_sirah', confidence: 0.7 };
  }

  // Jika tidak dapat dipastikan, lalai adalah dalam skop jika pendek atau ragu-ragu
  return { isInScope: true, confidence: 0.5 };
}

export function getOutOfScopeResponse(): {
  reply: string;
  suggestions: string[];
  expression: 'helper';
} {
  return {
    reply:
      'Wah, soalan yang menarik, adik! Saya Ustaz Cilik, teman pengembaraan Sirah kita. Saya boleh bantu adik mengenali kisah hidup Nabi Muhammad SAW. Jom kita terokai Sirah bersama-sama!',
    suggestions: [
      'Kembali ke Wahyu Pertama',
      'Terokai kisah Sirah lain',
      'Cuba kuiz Sirah',
      'Siapakah Malaikat Jibril AS?',
    ],
    expression: 'helper',
  };
}

/**
 * Pangkalan Data Jawapan Tempatan (Fallback Pantas & Tepat untuk Tahun 3)
 */
export const LOCAL_SIRAH_KNOWLEDGE: Array<{
  triggers: string[];
  reply: string;
  expression: 'explaining' | 'excited' | 'welcoming';
  followUp: string;
}> = [
  {
    triggers: ['maksud wahyu', 'apa itu wahyu', 'erti wahyu'],
    reply:
      'Wahyu ialah kalam suci daripada Allah SWT yang disampaikan kepada para nabi dan rasul melalui Malaikat Jibril AS. Wahyu menjadi panduan hidup yang membimbing manusia ke jalan yang benar.',
    expression: 'explaining',
    followUp: 'Adik mahu tahu di manakah wahyu pertama diturunkan?',
  },
  {
    triggers: ['tempat', 'gua hira', 'jabal nur', 'di mana', 'lokasi'],
    reply:
      'Wahyu pertama diturunkan di Gua Hira\', yang terletak di puncak bukit Jabal Nur berdekatan Kota Makkah. Nabi Muhammad SAW beribadah dan bertahannuth di sana.',
    expression: 'explaining',
    followUp: 'Tahukah adik berapakah usia Nabi SAW semasa berada di Gua Hira\'?',
  },
  {
    triggers: ['jibril', 'siapa malaikat', 'malaikat apa', 'pembawa wahyu'],
    reply:
      'Malaikat yang menyampaikan wahyu pertama ialah Malaikat Jibril Alaihissalam. Beliau memeluk Nabi Muhammad SAW dengan penuh kasih sambil menyampaikan perintah "Iqra\'!" (Bacalah!).',
    expression: 'explaining',
    followUp: 'Adik tahu apa makna perkataan Iqra\'?',
  },
  {
    triggers: ['iqra', 'ayat pertama', 'surah apa', 'surah al-alaq', 'bacalah'],
    reply:
      'Wahyu pertama ialah 5 ayat terawal daripada Surah Al-\'Alaq. Ayat ini bermula dengan "Iqra\' bismi rabbikallazi khalaq" yang bermaksud "Bacalah dengan nama Tuhanmu yang menciptakan".',
    expression: 'excited',
    followUp: 'Ini menunjukkan Islam sangat mementingkan ilmu dan membaca!',
  },
  {
    triggers: ['umur', 'berapa tahun', 'usia'],
    reply:
      'Nabi Muhammad SAW berusia genap 40 tahun semasa menerima wahyu pertama pada malam 17 Ramadan.',
    expression: 'explaining',
    followUp: 'Usia 40 tahun ialah usia kematangan Baginda diangkat menjadi Rasulullah.',
  },
  {
    triggers: ['khadijah', 'isteri', 'selimut', 'zammiluni'],
    reply:
      'Selepas menerima wahyu, Nabi Muhammad SAW berasa gementar lalu pulang ke rumah menemui isteri tercinta, Saidatina Khadijah RA. Khadijah menenangkan Baginda dan menyelimutkannya.',
    expression: 'explaining',
    followUp: 'Saidatina Khadijah RA ialah wanita pertama yang memeluk Islam!',
  },
  {
    triggers: ['pengajaran', 'apa kita belajar', 'hikmah', 'faedah'],
    reply:
      'Tiga pengajaran utama: 1) Kita wajib rajin membaca dan menuntut ilmu, 2) Sentiasa bersabar dan gigih menempuh cabaran, dan 3) Memulakan setiap amalan dengan menyebut nama Allah SWT (Bismillah).',
    expression: 'explaining',
    followUp: 'Adik sudah sedia untuk menguji pengetahuan dalam kuiz?',
  },
  {
    triggers: ['al-amin', 'gelaran', 'sifat nabi', 'akhlak'],
    reply:
      'Nabi Muhammad SAW digelar Al-Amin sejak muda kerana sifat Baginda yang sentiasa jujur, amanah dan tidak pernah berbohong. Baginda mempunyai sifat Siddiq, Amanah, Tabligh dan Fatonah.',
    expression: 'explaining',
    followUp: 'Jom kita contohi sifat jujur Rasulullah SAW di sekolah!',
  },
  {
    triggers: ['assalamualaikum', 'hai', 'halo', 'ustaz cilik', 'salam'],
    reply:
      'Waalaikumussalam adik yang soleh dan pintar! Saya Ustaz Cilik, sangat gembira dapat menemani adik meneroka kisah indah Sirah Nabi Muhammad SAW. Apa yang adik ingin tahu hari ini?',
    expression: 'welcoming',
    followUp: 'Adik boleh tanya tentang Wahyu Pertama atau kisah Baginda di Makkah dan Madinah!',
  },
];

export function findLocalSirahAnswer(query: string): {
  reply: string;
  expression: 'explaining' | 'excited' | 'welcoming';
  followUp?: string;
} | null {
  const normalized = query.toLowerCase().trim();

  for (const item of LOCAL_SIRAH_KNOWLEDGE) {
    for (const trigger of item.triggers) {
      if (normalized.includes(trigger)) {
        return {
          reply: item.reply,
          expression: item.expression,
          followUp: item.followUp,
        };
      }
    }
  }

  return null;
}
