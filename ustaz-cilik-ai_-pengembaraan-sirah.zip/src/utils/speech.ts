/**
 * Pembantu Audio & Sintesis Suara (Web Speech API)
 * Dioptimumkan untuk Bahasa Melayu Malaysia (ms-MY) dengan fallback santun.
 */

class SpeechHelper {
  private synth: SpeechSynthesis | null = null;
  private isSpeakingState = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private onStateChangeCallbacks: Array<(speaking: boolean) => void> = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public isSupported(): boolean {
    return this.synth !== null;
  }

  public subscribe(callback: (speaking: boolean) => void) {
    this.onStateChangeCallbacks.push(callback);
    return () => {
      this.onStateChangeCallbacks = this.onStateChangeCallbacks.filter((c) => c !== callback);
    };
  }

  private notify(speaking: boolean) {
    this.isSpeakingState = speaking;
    this.onStateChangeCallbacks.forEach((cb) => cb(speaking));
  }

  public speak(text: string, onEnd?: () => void) {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    // Hentikan suara sedia ada
    this.stop();

    // Bersihkan teks daripada tanda bacaan berlebihan
    const cleanText = text
      .replace(/[*#_~`]/g, '')
      .replace(/\n+/g, ' ')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    this.currentUtterance = utterance;

    // Cari suara Bahasa Melayu atau Bahasa Indonesia yang mesra
    const voices = this.synth.getVoices();
    const malayVoice = voices.find(
      (v) => v.lang === 'ms-MY' || v.lang === 'ms' || v.lang.startsWith('ms')
    ) || voices.find(
      (v) => v.lang === 'id-ID' || v.lang === 'id' || v.lang.startsWith('id')
    );

    if (malayVoice) {
      utterance.voice = malayVoice;
      utterance.lang = malayVoice.lang;
    } else {
      utterance.lang = 'ms-MY';
    }

    // Kelajuan sederhana untuk kanak-kanak Tahun 3 (tenang & jelas)
    utterance.rate = 0.9;
    utterance.pitch = 1.05; // Sedikit ceria dan mesra

    utterance.onstart = () => {
      this.notify(true);
    };

    utterance.onend = () => {
      this.notify(false);
      this.currentUtterance = null;
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis notice:', e);
      this.notify(false);
      this.currentUtterance = null;
      if (onEnd) onEnd();
    };

    this.synth.speak(utterance);
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.notify(false);
      this.currentUtterance = null;
    }
  }

  public isSpeaking(): boolean {
    return this.isSpeakingState;
  }
}

export const speechService = new SpeechHelper();
