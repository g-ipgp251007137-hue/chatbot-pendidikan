import React, { useState } from 'react';
import { LearningObjective, InfographicSection, QuizQuestion } from '../logic/sirahData';
import { ObjectiveMastery } from '../logic/quizRules';
import {
  ArrowLeft,
  ShieldCheck,
  Upload,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  Plus,
  Save,
  Image as ImageIcon,
  FileText,
} from 'lucide-react';

interface TeacherPanelProps {
  onBack: () => void;
  objectives: LearningObjective[];
  masteryMap: Record<string, ObjectiveMastery>;
  infographicSections: InfographicSection[];
  onUpdateInfographic: (sections: InfographicSection[]) => void;
  quizQuestions: QuizQuestion[];
  onUpdateQuizQuestions: (questions: QuizQuestion[]) => void;
  customInfographicUrl: string | null;
  onSetCustomInfographicUrl: (url: string | null) => void;
  customMascotUrl: string | null;
  onSetCustomMascotUrl: (url: string | null) => void;
  onResetSession: () => void;
}

export const TeacherPanel: React.FC<TeacherPanelProps> = ({
  onBack,
  objectives,
  masteryMap,
  infographicSections,
  onUpdateInfographic,
  quizQuestions,
  onUpdateQuizQuestions,
  customInfographicUrl,
  onSetCustomInfographicUrl,
  customMascotUrl,
  onSetCustomMascotUrl,
  onResetSession,
}) => {
  const [activeTab, setActiveTab] = useState<'assure' | 'infographic' | 'quiz' | 'media'>('assure');
  const [infographicState, setInfographicState] = useState<InfographicSection[]>(infographicSections);
  const [quizState, setQuizState] = useState<QuizQuestion[]>(quizQuestions);
  const [tempInfographicUrl, setTempInfographicUrl] = useState(customInfographicUrl || '');
  const [tempMascotUrl, setTempMascotUrl] = useState(customMascotUrl || '');
  const [saveToast, setSaveToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSaveToast(msg);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleSaveInfographic = () => {
    onUpdateInfographic(infographicState);
    showToast('Kandungan Infografik berjaya dikemaskini!');
  };

  const handleSaveQuiz = () => {
    onUpdateQuizQuestions(quizState);
    showToast('Soalan Kuiz berjaya dikemaskini!');
  };

  const handleApplyMedia = () => {
    onSetCustomInfographicUrl(tempInfographicUrl.trim() || null);
    onSetCustomMascotUrl(tempMascotUrl.trim() || null);
    showToast('Imej tersuai berjaya disimpan!');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'infographic' | 'mascot') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (type === 'infographic') {
          setTempInfographicUrl(result);
          onSetCustomInfographicUrl(result);
          showToast('Fail infografik berjaya dimuat naik!');
        } else {
          setTempMascotUrl(result);
          onSetCustomMascotUrl(result);
          showToast('Fail maskot berjaya dimuat naik!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between p-4 selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Atas */}
      <header className="max-w-6xl mx-auto w-full flex items-center justify-between py-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs md:text-sm transition"
        >
          <ArrowLeft className="w-4 h-4 text-amber-400" />
          <span>Kembali ke Aplikasi</span>
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm md:text-base font-black text-white">
              Panel Pengurusan Guru
            </h2>
            <p className="text-[10px] text-slate-400">
              Model ASSURE & Kawalan Kandungan Sirah Tahun 3
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            if (confirm('Adakah anda pasti mahu memulakan semula statistik sesi murid?')) {
              onResetSession();
              showToast('Sesi telah dimulakan semula.');
            }
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-900/60 hover:bg-red-800 text-red-200 border border-red-700/60 text-xs font-semibold"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Mula Semula Sesi</span>
        </button>
      </header>

      {/* Baris Tab Navigasi Mod Guru */}
      <div className="max-w-6xl mx-auto w-full my-4 flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setActiveTab('assure')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'assure'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>1. Analisis Objektif (ASSURE)</span>
        </button>

        <button
          onClick={() => setActiveTab('infographic')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'infographic'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>2. Teks Infografik</span>
        </button>

        <button
          onClick={() => setActiveTab('quiz')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'quiz'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>3. Soalan Kuiz</span>
        </button>

        <button
          onClick={() => setActiveTab('media')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'media'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>4. Muat Naik Bahan Guru</span>
        </button>
      </div>

      {/* Notifikasi Toast */}
      {saveToast && (
        <div className="max-w-md mx-auto w-full bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 rounded-2xl shadow-xl text-center mb-2 animate-bounce">
          {saveToast}
        </div>
      )}

      {/* Kandungan Tab */}
      <main className="max-w-6xl mx-auto w-full flex-1">
        {/* TAB 1: MODEL ASSURE & ANALISIS OBJEKTIF */}
        {activeTab === 'assure' && (
          <div className="space-y-4">
            <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6 shadow-xl">
              <h3 className="text-base font-black text-amber-400 mb-1">
                E — Evaluate &amp; Revise (Penilaian Objektif Pembelajaran ASSURE)
              </h3>
              <p className="text-xs text-slate-300 mb-6">
                Data penilaian dikumpulkan secara langsung daripada jawapan murid pada sesi semasa tanpa merekod maklumat peribadi.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {objectives.map((obj) => {
                  const m = masteryMap[obj.id] || { totalQuestions: 0, correctQuestions: 0, percentage: 0, isMastered: false };

                  return (
                    <div
                      key={obj.id}
                      className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-0.5 rounded-md bg-amber-400/20 text-amber-300 text-xs font-black">
                            {obj.code}
                          </span>
                          <span
                            className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                              m.isMastered
                                ? 'bg-emerald-900 text-emerald-300 border border-emerald-600'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {m.isMastered ? 'Dikuasai ✓' : 'Belum Dikuasai'}
                          </span>
                        </div>

                        <h4 className="font-bold text-sm text-white">{obj.title}</h4>
                        <p className="text-xs text-slate-400 mt-1">{obj.description}</p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-800">
                        <div className="flex justify-between text-xs text-slate-300 mb-1">
                          <span>Kadar Ketepatan Sesi:</span>
                          <span className="font-bold text-amber-300">
                            {m.correctQuestions} / {m.totalQuestions} ({m.percentage}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full transition-all"
                            style={{ width: `${m.percentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: TEKS INFOGRAFIK */}
        {activeTab === 'infographic' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-slate-800/80 p-4 rounded-2xl border border-slate-700">
              <div>
                <h3 className="font-bold text-sm text-white">Semakan &amp; Suntingan Infografik</h3>
                <p className="text-xs text-slate-400">
                  Guru boleh menyemak dan meminda teks yang dipaparkan dalam infografik Wahyu Pertama.
                </p>
              </div>
              <button
                onClick={handleSaveInfographic}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan</span>
              </button>
            </div>

            <div className="space-y-3">
              {infographicState.map((sec, idx) => (
                <div key={sec.id} className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <input
                      type="text"
                      value={sec.title}
                      onChange={(e) => {
                        const copy = [...infographicState];
                        copy[idx].title = e.target.value;
                        setInfographicState(copy);
                      }}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Ringkasan Fakta:</label>
                    <textarea
                      rows={2}
                      value={sec.summary}
                      onChange={(e) => {
                        const copy = [...infographicState];
                        copy[idx].summary = e.target.value;
                        setInfographicState(copy);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Penerangan Ustaz Cilik:</label>
                    <textarea
                      rows={2}
                      value={sec.explanation}
                      onChange={(e) => {
                        const copy = [...infographicState];
                        copy[idx].explanation = e.target.value;
                        setInfographicState(copy);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: SOALAN KUIZ */}
        {activeTab === 'quiz' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-slate-800/80 p-4 rounded-2xl border border-slate-700">
              <div>
                <h3 className="font-bold text-sm text-white">Pengurusan Soalan Kuiz</h3>
                <p className="text-xs text-slate-400">
                  Guru boleh menambah atau mengemas kini pilihan jawapan dan petunjuk.
                </p>
              </div>
              <button
                onClick={handleSaveQuiz}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Soalan Kuiz</span>
              </button>
            </div>

            <div className="space-y-3">
              {quizState.map((q, qIdx) => (
                <div key={q.id} className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400">
                      Soalan {qIdx + 1} ({q.topic})
                    </span>
                    <span className="text-[10px] bg-slate-700 px-2 py-0.5 rounded text-slate-300">
                      Jawapan Betul: Indeks {q.correctIndex} ({q.options[q.correctIndex]})
                    </span>
                  </div>

                  <input
                    type="text"
                    value={q.question}
                    onChange={(e) => {
                      const copy = [...quizState];
                      copy[qIdx].question = e.target.value;
                      setQuizState(copy);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold"
                  />

                  <div className="space-y-1.5">
                    <label className="text-[11px] text-slate-400 block">Pilihan Jawapan:</label>
                    {q.options.map((opt, oIdx) => (
                      <div key={oIdx} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct_${q.id}`}
                          checked={q.correctIndex === oIdx}
                          onChange={() => {
                            const copy = [...quizState];
                            copy[qIdx].correctIndex = oIdx;
                            setQuizState(copy);
                          }}
                        />
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const copy = [...quizState];
                            copy[qIdx].options[oIdx] = e.target.value;
                            setQuizState(copy);
                          }}
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200"
                        />
                      </div>
                    ))}
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block">Petunjuk (Hint):</label>
                    <input
                      type="text"
                      value={q.hint}
                      onChange={(e) => {
                        const copy = [...quizState];
                        copy[qIdx].hint = e.target.value;
                        setQuizState(copy);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-amber-200"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: MUAT NAIK BAHAN GURU */}
        {activeTab === 'media' && (
          <div className="space-y-6">
            {/* Infografik Guru */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6">
              <h3 className="font-bold text-sm text-white mb-1">
                Muat Naik / Tetapkan Infografik Wahyu Pertama
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Guru boleh memuat naik imej carta infografik rasmi sekolah atau memasukkan pautan URL imej.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md">
                  <Upload className="w-4 h-4" />
                  <span>Pilih Fail Imej Infografik</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'infographic')}
                  />
                </label>

                <input
                  type="text"
                  placeholder="Atau masukkan pautan URL imej..."
                  value={tempInfographicUrl}
                  onChange={(e) => setTempInfographicUrl(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />

                <button
                  onClick={handleApplyMedia}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                >
                  Guna Imej Ini
                </button>
              </div>

              {customInfographicUrl && (
                <div className="mt-4 p-3 bg-slate-900 rounded-2xl border border-slate-700 flex items-center justify-between">
                  <span className="text-xs text-emerald-400 font-semibold">
                    Imej infografik tersuai sedang aktif ✓
                  </span>
                  <button
                    onClick={() => {
                      onSetCustomInfographicUrl(null);
                      setTempInfographicUrl('');
                      showToast('Kembali kepada infografik ilustrasi asal.');
                    }}
                    className="text-xs text-red-400 hover:underline"
                  >
                    Padam Imej
                  </button>
                </div>
              )}
            </div>

            {/* Maskot Guru */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6">
              <h3 className="font-bold text-sm text-white mb-1">
                Muat Naik / Tetapkan Imej Maskot Ustaz Cilik
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Sekiranya guru mempunyai ilustrasi rasmi maskot Ustaz Cilik tersendiri, anda boleh menetapkannya di sini.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md">
                  <Upload className="w-4 h-4" />
                  <span>Pilih Fail Imej Maskot</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'mascot')}
                  />
                </label>

                <input
                  type="text"
                  placeholder="Atau masukkan pautan URL imej maskot..."
                  value={tempMascotUrl}
                  onChange={(e) => setTempMascotUrl(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />

                <button
                  onClick={handleApplyMedia}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                >
                  Guna Maskot Ini
                </button>
              </div>

              {customMascotUrl && (
                <div className="mt-4 p-3 bg-slate-900 rounded-2xl border border-slate-700 flex items-center justify-between">
                  <span className="text-xs text-emerald-400 font-semibold">
                    Imej maskot tersuai sedang aktif ✓
                  </span>
                  <button
                    onClick={() => {
                      onSetCustomMascotUrl(null);
                      setTempMascotUrl('');
                      showToast('Kembali kepada maskot 3D ilustrasi asal.');
                    }}
                    className="text-xs text-red-400 hover:underline"
                  >
                    Padam Maskot Tersuai
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer className="max-w-6xl mx-auto w-full py-2 text-center text-xs text-slate-500 border-t border-slate-800">
        Panel Guru Ustaz Cilik AI • Tiada data sulit murid dikumpulkan
      </footer>
    </div>
  );
};
