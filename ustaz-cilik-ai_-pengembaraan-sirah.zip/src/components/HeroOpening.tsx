import React from 'react';
import { UstazCilikMascot } from './UstazCilikMascot';
import { Compass, MessageCircleQuestion, HelpCircle, Sparkles, Volume2, VolumeX, Monitor, ShieldCheck } from 'lucide-react';

interface HeroOpeningProps {
  onStartAdventure: () => void;
  onAskQuestion: () => void;
  onHowToPlay: () => void;
  onTogglePresentation: () => void;
  onOpenTeacherPanel: () => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
  customMascotUrl?: string | null;
}

export const HeroOpening: React.FC<HeroOpeningProps> = ({
  onStartAdventure,
  onAskQuestion,
  onHowToPlay,
  onTogglePresentation,
  onOpenTeacherPanel,
  isAudioMuted,
  onToggleAudio,
  customMascotUrl,
}) => {
  return (
    <div className="relative min-h-screen flex flex-col justify-between overflow-hidden bg-gradient-to-b from-emerald-900 via-emerald-800 to-teal-950 text-white selection:bg-amber-400 selection:text-emerald-950">
      {/* Corak Geometri Islamik Halus di Latar Belakang */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#fbbf24_1px,transparent_1px)] [background-size:24px_24px]" />

      {/* Cahaya Emas Lembut dari Atas */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-b from-amber-300/20 via-emerald-400/10 to-transparent blur-3xl pointer-events-none" />

      {/* Bar Navigasi Atas (Aksesibiliti & Mod Guru / Pembentangan) */}
      <header className="relative z-10 w-full max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 flex items-center justify-center shadow-lg shadow-amber-400/20 text-emerald-950 font-black text-xl">
            ✨
          </div>
          <div>
            <h1 className="font-extrabold text-sm md:text-base tracking-wide text-amber-200">
              USTAZ CILIK AI
            </h1>
            <p className="text-[11px] text-emerald-200/80 font-medium">
              Pendidikan Islam Tahun 3 (KSSR)
            </p>
          </div>
        </div>

        {/* Butang Kawalan Pantas */}
        <div className="flex items-center gap-2">
          {/* Suara */}
          <button
            onClick={onToggleAudio}
            aria-label={isAudioMuted ? 'Buka audio suara' : 'Senyapkan suara'}
            className="p-2.5 rounded-xl bg-emerald-800/80 hover:bg-emerald-700/80 text-emerald-100 hover:text-white transition shadow-sm border border-emerald-700/50 flex items-center gap-1.5 text-xs font-semibold"
          >
            {isAudioMuted ? <VolumeX className="w-4 h-4 text-amber-300" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
            <span className="hidden sm:inline">{isAudioMuted ? 'Bisu' : 'Audio Aktif'}</span>
          </button>

          {/* Mod Pembentangan 16:9 */}
          <button
            onClick={onTogglePresentation}
            aria-label="Buka Mod Pembentangan Projektor 16:9"
            className="p-2.5 rounded-xl bg-teal-800/80 hover:bg-teal-700/80 text-teal-100 hover:text-white transition shadow-sm border border-teal-700/50 flex items-center gap-1.5 text-xs font-semibold"
          >
            <Monitor className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">Mod Projektor</span>
          </button>

          {/* Mod Guru */}
          <button
            onClick={onOpenTeacherPanel}
            aria-label="Buka Panel Kawalan Guru"
            className="p-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 hover:text-amber-100 transition shadow-sm border border-amber-400/40 flex items-center gap-1.5 text-xs font-semibold"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Panel Guru</span>
          </button>
        </div>
      </header>

      {/* Bahagian Utama (Hero & Maskot) */}
      <main className="relative z-10 flex-1 max-w-5xl mx-auto px-4 flex flex-col items-center justify-center text-center py-6">
        {/* Lencana Selamat Datang */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-800/90 border border-emerald-600/60 text-amber-300 text-xs md:text-sm font-semibold mb-4 shadow-lg backdrop-blur-sm">
          <Sparkles className="w-4 h-4 animate-spin text-amber-300" style={{ animationDuration: '6s' }} />
          <span>Jom Terokai Sirah, Belajar dengan Gembira!</span>
        </div>

        {/* Tajuk Utama */}
        <h2 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tight text-white mb-2 drop-shadow-md">
          PENGEMBARAAN <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400">SIRAH</span>
        </h2>

        {/* Subtajuk */}
        <p className="text-base md:text-xl text-emerald-100 max-w-2xl font-medium mb-6 leading-relaxed">
          Temui kisah agung Nabi Muhammad SAW bersama Ustaz Cilik! Misi bermula di Gua Hira&apos; untuk menyingkap detik peristiwa Wahyu Pertama.
        </p>

        {/* Maskot Ustaz Cilik Menyambut Murid */}
        <div className="my-2 flex justify-center">
          <UstazCilikMascot
            expression="welcoming"
            size="lg"
            bubbleText="Assalamualaikum, adik-adik! Selamat datang ke Pengembaraan Sirah! Jom kita mulakan misi hari ini!"
            customImageUrl={customMascotUrl}
          />
        </div>

        {/* 3 Butang Tindakan Utama Berkesan */}
        <div className="w-full max-w-xl grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mt-6">
          {/* Butang 1: MULAKAN PENGEMBARAAN (Paling Besar & Berseri) */}
          <button
            onClick={onStartAdventure}
            className="sm:col-span-3 group relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 p-0.5 shadow-2xl shadow-amber-500/30 hover:shadow-amber-400/50 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
          >
            <div className="flex items-center justify-center gap-3 px-8 py-4 rounded-[14px] bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 text-emerald-950 font-black text-lg md:text-xl tracking-wide shadow-inner">
              <Compass className="w-6 h-6 text-emerald-950 animate-bounce" />
              <span>MULAKAN PENGEMBARAAN</span>
            </div>
          </button>

          {/* Butang 2: SAYA MAHU BERTANYA */}
          <button
            onClick={onAskQuestion}
            className="sm:col-span-2 group rounded-2xl bg-emerald-700/80 hover:bg-emerald-600/90 text-white font-bold p-3.5 border border-emerald-500/50 shadow-lg hover:shadow-emerald-500/30 transition-all duration-200 flex items-center justify-center gap-2.5 text-sm md:text-base hover:scale-[1.01]"
          >
            <MessageCircleQuestion className="w-5 h-5 text-amber-300 group-hover:scale-110 transition-transform" />
            <span>SAYA MAHU BERTANYA</span>
          </button>

          {/* Butang 3: CARA BERMAIN */}
          <button
            onClick={onHowToPlay}
            className="rounded-2xl bg-teal-900/80 hover:bg-teal-800/90 text-emerald-200 hover:text-white font-semibold p-3.5 border border-teal-700/60 shadow-lg transition-all duration-200 flex items-center justify-center gap-2 text-sm md:text-base hover:scale-[1.01]"
          >
            <HelpCircle className="w-5 h-5 text-amber-300" />
            <span>CARA BERMAIN</span>
          </button>
        </div>
      </main>

      {/* Kaki Halaman (Rujukan KSSR & Adab) */}
      <footer className="relative z-10 w-full max-w-5xl mx-auto px-4 py-3 text-center text-xs text-emerald-300/70 border-t border-emerald-800/40">
        <p>Berasaskan Model ASSURE & Sukatan Pendidikan Islam Tahun 3 • Menghayati Sirah Nabi Muhammad SAW</p>
      </footer>
    </div>
  );
};
