import React, { useState } from 'react';
import { UstazCilikMascot, MascotExpression } from './UstazCilikMascot';
import { BookOpen, MessageSquare, Award, Volume2, ArrowLeft, Mountain, CheckCircle2, MapPin } from 'lucide-react';
import { speechService } from '../utils/speech';

interface GuaHiraPortalProps {
  onLearnInfographic: () => void;
  onAskChatbot: () => void;
  onStartQuiz: () => void;
  onBackToMap: () => void;
  onViewAchievements: () => void;
  completedObjectivesCount: number;
  totalObjectivesCount: number;
  customMascotUrl?: string | null;
}

export const GuaHiraPortal: React.FC<GuaHiraPortalProps> = ({
  onLearnInfographic,
  onAskChatbot,
  onStartQuiz,
  onBackToMap,
  onViewAchievements,
  completedObjectivesCount,
  totalObjectivesCount,
  customMascotUrl,
}) => {
  const [mascotExp, setMascotExp] = useState<MascotExpression>('welcoming');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const introText =
    "Assalamualaikum, murid-murid! Selamat datang ke Portal Gua Hira'! Hari ini kita akan mempelajari peristiwa Wahyu Pertama. Jom kita terokai bersama-sama!";

  const handleSpeakIntro = () => {
    if (speechService.isSpeaking()) {
      speechService.stop();
      setIsSpeaking(false);
      setMascotExp('welcoming');
    } else {
      setIsSpeaking(true);
      setMascotExp('explaining');
      speechService.speak(introText, () => {
        setIsSpeaking(false);
        setMascotExp('encouraging');
      });
    }
  };

  const progressPercent =
    totalObjectivesCount > 0 ? Math.round((completedObjectivesCount / totalObjectivesCount) * 100) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Navigasi Atas Portal */}
      <header className="w-full max-w-6xl mx-auto px-4 py-4 flex items-center justify-between z-10">
        <button
          onClick={onBackToMap}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Peta Pengembaraan</span>
        </button>

        {/* Tajuk & Lokasi */}
        <div className="flex items-center gap-2 bg-emerald-900/60 px-4 py-1.5 rounded-full border border-emerald-600/40 text-xs md:text-sm font-semibold text-emerald-200">
          <MapPin className="w-4 h-4 text-amber-400" />
          <span>Gua Hira&apos;, Jabal Nur (Makkah)</span>
        </div>

        {/* Lencana Murid */}
        <button
          onClick={onViewAchievements}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>Lencana Saya</span>
        </button>
      </header>

      {/* Kandungan Utama Portal Gua Hira' */}
      <main className="max-w-5xl mx-auto px-4 py-4 w-full flex-1 flex flex-col items-center">
        {/* Papan Informasi Misi 1 */}
        <div className="w-full bg-gradient-to-r from-emerald-900/90 via-teal-900/90 to-emerald-900/90 border-2 border-amber-400/50 rounded-3xl p-5 shadow-2xl backdrop-blur-md mb-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-center md:text-left">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center text-emerald-950 font-black shadow-lg shadow-amber-500/20">
                <Mountain className="w-8 h-8 text-emerald-950" />
              </div>
              <div>
                <span className="text-xs font-bold text-amber-300 uppercase tracking-widest">
                  Misi Utama Tahun 3
                </span>
                <h2 className="text-2xl md:text-3xl font-black text-white">
                  Misi 1: Wahyu Pertama
                </h2>
                <p className="text-xs md:text-sm text-emerald-200">
                  Peristiwa kemuliaan penurunan ayat pertama Al-Quran di puncak Jabal Nur.
                </p>
              </div>
            </div>

            {/* Tolok Kemajuan Objektif */}
            <div className="flex flex-col items-center md:items-end w-full md:w-56 bg-emerald-950/60 p-3 rounded-2xl border border-emerald-700/50">
              <div className="flex justify-between w-full text-xs font-semibold text-emerald-200 mb-1.5">
                <span>Penguasaan Objektif:</span>
                <span className="text-amber-300">{completedObjectivesCount}/{totalObjectivesCount}</span>
              </div>
              <div className="w-full bg-emerald-900 h-3 rounded-full overflow-hidden border border-emerald-700">
                <div
                  className="bg-gradient-to-r from-amber-400 to-emerald-400 h-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <span className="text-[11px] text-emerald-300 mt-1">
                {progressPercent === 100 ? 'Tahniah! Semua Objektif Selesai!' : 'Teruskan langkah untuk lencana!'}
              </span>
            </div>
          </div>
        </div>

        {/* Ilustrasi Gua Hira' & Jabal Nur Bersama Maskot */}
        <div className="relative w-full max-w-4xl min-h-[300px] md:min-h-[340px] rounded-3xl overflow-hidden border-2 border-emerald-600/50 shadow-2xl bg-gradient-to-b from-sky-950 via-teal-950 to-stone-900 flex items-end justify-center mb-6 pt-6 pb-2">
          {/* Latar Belakang Gunung Jabal Nur & Cahaya Bintang Malam 17 Ramadan */}
          <div className="absolute inset-0">
            {/* Langit malam dan bintang berkerlipan */}
            <div className="absolute inset-0 bg-[radial-gradient(#fde047_1px,transparent_1px)] [background-size:28px_28px] opacity-40" />
            <div className="absolute top-4 right-8 w-12 h-12 rounded-full bg-amber-100 shadow-[0_0_40px_rgba(254,243,199,0.8)] opacity-90" />
            
            {/* Siluet Pergunungan Jabal Nur yang Sopan & Bermakna */}
            <svg
              viewBox="0 0 800 300"
              className="absolute bottom-0 w-full h-full object-cover"
              preserveAspectRatio="none"
            >
              {/* Bukit belakang */}
              <path d="M 0 300 L 150 140 L 320 220 L 500 110 L 680 200 L 800 150 L 800 300 Z" fill="#0f172a" opacity="0.6" />
              {/* Bukit tengah Jabal Nur */}
              <path d="M 0 300 L 220 120 L 400 80 L 580 160 L 800 240 L 800 300 Z" fill="#1e293b" opacity="0.8" />
              {/* Puncak Gua Hira' dengan Cahaya Emas Hikmah */}
              <circle cx="400" cy="80" r="40" fill="#fbbf24" opacity="0.15" />
              {/* Laluan mendaki ke Gua Hira' */}
              <path d="M 100 300 Q 250 240 380 130" stroke="#f59e0b" strokeWidth="3" strokeDasharray="6 6" fill="none" opacity="0.6" />
            </svg>

            {/* Label Lokasi di Ilustrasi */}
            <div className="absolute top-4 left-4 bg-emerald-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/40 text-xs font-semibold text-emerald-200 flex items-center gap-2">
              <Mountain className="w-3.5 h-3.5 text-amber-400" />
              <span>Gua Hira&apos;, Jabal Nur (Malam 17 Ramadan)</span>
            </div>
          </div>

          {/* Maskot Ustaz Cilik di Hadapan Gua Hira' */}
          <div className="relative z-10 my-2">
            <UstazCilikMascot
              expression={mascotExp}
              size="md"
              isSpeaking={isSpeaking}
              bubbleText={introText}
              customImageUrl={customMascotUrl}
            />
          </div>
        </div>

        {/* 4 Pilihan Tindakan Utama Berdasarkan Panduan Pedagogi */}
        <div className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          {/* Pilihan 1: JOM BELAJAR! (Infografik) */}
          <button
            onClick={onLearnInfographic}
            className="group relative overflow-hidden rounded-2xl bg-gradient-to-b from-emerald-700 to-emerald-800 hover:from-emerald-600 hover:to-emerald-700 p-4 border-2 border-emerald-400/60 shadow-xl transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-110 transition-transform">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-base md:text-lg text-white mb-1">
                1. Jom Belajar!
              </h3>
              <p className="text-xs text-emerald-100 leading-snug">
                Terokai Infografik Wahyu Pertama yang penuh warna dan fakta disahkan guru.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-amber-300">
              <span>Buka Infografik</span>
              <span>→</span>
            </div>
          </button>

          {/* Pilihan 2: SAYA MAHU BERTANYA (Chatbot) */}
          <button
            onClick={onAskChatbot}
            className="group relative overflow-hidden rounded-2xl bg-gradient-to-b from-teal-700 to-teal-800 hover:from-teal-600 hover:to-teal-700 p-4 border-2 border-teal-400/60 shadow-xl transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-400 text-teal-950 flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-110 transition-transform">
                <MessageSquare className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-base md:text-lg text-white mb-1">
                2. Mahu Bertanya
              </h3>
              <p className="text-xs text-teal-100 leading-snug">
                Tanya apa sahaja soalan tentang peristiwa Wahyu Pertama &amp; Sirah Nabi SAW!
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-amber-300">
              <span>Tanya Ustaz Cilik</span>
              <span>→</span>
            </div>
          </button>

          {/* Pilihan 3: UJI PENGETAHUAN SAYA! (Kuiz) */}
          <button
            onClick={onStartQuiz}
            className="group relative overflow-hidden rounded-2xl bg-gradient-to-b from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 p-4 border-2 border-amber-300/80 shadow-xl transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-white text-amber-700 flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-110 transition-transform">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-base md:text-lg text-white mb-1">
                3. Uji Pengetahuan!
              </h3>
              <p className="text-xs text-amber-100 leading-snug">
                Jawab soalan santai, kumpul bintang dan menangi lencana kejayaan!
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-white">
              <span>Mulakan Kuiz</span>
              <span>→</span>
            </div>
          </button>

          {/* Pilihan 4: DENGAR PENERANGAN (Audio Pertuturan) */}
          <button
            onClick={handleSpeakIntro}
            className="group relative overflow-hidden rounded-2xl bg-gradient-to-b from-emerald-900 to-stone-900 hover:from-emerald-800 hover:to-stone-800 p-4 border-2 border-emerald-500/50 shadow-xl transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-110 transition-transform">
                <Volume2 className={`w-6 h-6 ${isSpeaking ? 'animate-bounce text-amber-300' : ''}`} />
              </div>
              <h3 className="font-extrabold text-base md:text-lg text-white mb-1">
                4. Dengar Suara
              </h3>
              <p className="text-xs text-emerald-200 leading-snug">
                {isSpeaking ? 'Sedang membacakan... Tekan untuk berhenti.' : 'Dengar suara Ustaz Cilik membacakan penerangan ringkas.'}
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-amber-300">
              <span>{isSpeaking ? 'Hentikan Suara' : 'Mainkan Audio'}</span>
            </div>
          </button>
        </div>
      </main>

      {/* Kaki Navigasi */}
      <footer className="w-full max-w-5xl mx-auto px-4 py-3 text-center text-xs text-emerald-300/60 border-t border-emerald-800/40">
        Pendidikan Islam Tahun 3 • Misi Wahyu Pertama &amp; Gua Hira&apos;
      </footer>
    </div>
  );
};
