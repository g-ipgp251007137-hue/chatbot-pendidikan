import React, { useState, useRef, useEffect } from 'react';
import { UstazCilikMascot, MascotExpression } from './UstazCilikMascot';
import { speechService } from '../utils/speech';
import {
  Send,
  Volume2,
  VolumeX,
  Trash2,
  ArrowLeft,
  Sparkles,
  HelpCircle,
  AlertCircle,
  BookOpen,
} from 'lucide-react';

export interface ChatMessageItem {
  id: string;
  sender: 'user' | 'ustaz';
  text: string;
  timestamp: string;
  expression?: MascotExpression;
  isOutOfScope?: boolean;
}

interface ChatWindowProps {
  onBack: () => void;
  onQuestionAsked: () => void;
  onOpenInfographic: () => void;
  initialQuestion?: string;
  customMascotUrl?: string | null;
}

const DEFAULT_SUGGESTIONS = [
  'Apakah maksud wahyu?',
  'Di manakah letaknya Gua Hira\'?',
  'Siapakah Malaikat Jibril AS?',
  'Berapa umur Nabi SAW ketika wahyu pertama?',
  'Apakah 3 pengajaran wahyu pertama?',
  'Mengapa Nabi SAW suka ke Gua Hira\'?',
];

export const ChatWindow: React.FC<ChatWindowProps> = ({
  onBack,
  onQuestionAsked,
  onOpenInfographic,
  initialQuestion,
  customMascotUrl,
}) => {
  const [messages, setMessages] = useState<ChatMessageItem[]>([
    {
      id: 'welcome_1',
      sender: 'ustaz',
      text: 'Assalamualaikum, adik! Saya Ustaz Cilik. Saya sedia membantu adik meneroka kisah Sirah Nabi Muhammad SAW. Adik boleh bertanya tentang Wahyu Pertama atau mana-mana peristiwa Sirah yang ingin adik ketahui. Jom belajar bersama-sama!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      expression: 'welcoming',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentMascotExp, setCurrentMascotExp] = useState<MascotExpression>('welcoming');
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [activeSuggestions, setActiveSuggestions] = useState<string[]>(DEFAULT_SUGGESTIONS);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Sekiranya ada soalan permulaan dihantar dari infografik
  useEffect(() => {
    if (initialQuestion && initialQuestion.trim()) {
      handleSendMessage(initialQuestion);
    }
  }, [initialQuestion]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    speechService.stop();
    setCurrentlySpeakingId(null);

    const userMsg: ChatMessageItem = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);
    setCurrentMascotExp('thinking');
    onQuestionAsked();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-6),
        }),
      });

      if (!response.ok) {
        throw new Error('Gagal menghubungi Ustaz Cilik.');
      }

      const data = await response.json();
      const ustazExp: MascotExpression = (data.expression as MascotExpression) || 'explaining';

      const ustazMsg: ChatMessageItem = {
        id: `ustaz_${Date.now()}`,
        sender: 'ustaz',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        expression: ustazExp,
        isOutOfScope: Boolean(data.isOutOfScope),
      };

      setMessages((prev) => [...prev, ustazMsg]);
      setCurrentMascotExp(ustazExp);

      if (Array.isArray(data.suggestions) && data.suggestions.length > 0) {
        setActiveSuggestions(data.suggestions);
      }
    } catch (error) {
      console.error('Error fetching chat response:', error);
      const fallbackMsg: ChatMessageItem = {
        id: `ustaz_${Date.now()}`,
        sender: 'ustaz',
        text: 'Alhamdulillah, soalan adik sangat bermakna! Wahyu pertama diturunkan kepada Nabi Muhammad SAW di Gua Hira\' melalui Malaikat Jibril AS. Peristiwa ini mengajar kita supaya rajin menuntut ilmu dan membaca.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        expression: 'explaining',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      setCurrentMascotExp('explaining');
    } finally {
      setIsLoading(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  const handleSpeak = (msgId: string, text: string) => {
    if (currentlySpeakingId === msgId) {
      speechService.stop();
      setCurrentlySpeakingId(null);
      setCurrentMascotExp('welcoming');
    } else {
      setCurrentlySpeakingId(msgId);
      setCurrentMascotExp('explaining');
      speechService.speak(text, () => {
        setCurrentlySpeakingId(null);
        setCurrentMascotExp('welcoming');
      });
    }
  };

  const handleClearChat = () => {
    speechService.stop();
    setCurrentlySpeakingId(null);
    setMessages([
      {
        id: 'welcome_re',
        sender: 'ustaz',
        text: 'Perbualan telah dibersihkan! Apa lagi yang adik ingin pelajari tentang Sirah Nabi Muhammad SAW hari ini?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        expression: 'welcoming',
      },
    ]);
    setActiveSuggestions(DEFAULT_SUGGESTIONS);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Navigasi Atas Chatbot */}
      <header className="w-full max-w-5xl mx-auto px-4 py-3 flex items-center justify-between border-b border-emerald-800/60 z-10">
        <button
          onClick={() => {
            speechService.stop();
            onBack();
          }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Kembali</span>
        </button>

        {/* Profil Maskot Mini */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-emerald-700 border-2 border-amber-400 overflow-hidden flex items-center justify-center shadow-md">
            <span className="text-sm font-bold">✨</span>
          </div>
          <div>
            <h2 className="text-sm md:text-base font-extrabold text-white leading-tight">
              Ustaz Cilik AI
            </h2>
            <p className="text-[10px] md:text-xs text-emerald-300 font-medium">
              Teman Pintar Sirah Kanak-Kanak
            </p>
          </div>
        </div>

        {/* Butang Tindakan */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenInfographic}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-800/70 hover:bg-teal-700 text-teal-100 border border-teal-600/50 text-xs font-semibold"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">Infografik</span>
          </button>
          <button
            onClick={handleClearChat}
            title="Bersihkan perbualan"
            className="p-2 rounded-xl bg-emerald-900/70 hover:bg-red-900/60 text-emerald-300 hover:text-red-200 border border-emerald-700/50 transition"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Ruang Perbualan Utama */}
      <main className="max-w-4xl mx-auto px-4 py-4 w-full flex-1 flex flex-col justify-between overflow-hidden">
        {/* Senarai Mesej Berbual */}
        <div className="flex-1 overflow-y-auto pr-2 space-y-4 mb-3 max-h-[60vh] scrollbar-thin">
          {messages.map((msg) => {
            const isUstaz = msg.sender === 'ustaz';
            const isSpeakingThis = currentlySpeakingId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-3 items-end ${isUstaz ? 'justify-start' : 'justify-end'}`}
              >
                {isUstaz && (
                  <div className="flex-shrink-0 mb-1">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 border-2 border-amber-300 flex items-center justify-center shadow-md">
                      <span className="text-xs font-black text-emerald-950">UC</span>
                    </div>
                  </div>
                )}

                <div
                  className={`max-w-[85%] md:max-w-[75%] rounded-3xl p-4 shadow-xl text-sm leading-relaxed ${
                    isUstaz
                      ? 'bg-gradient-to-br from-emerald-900/90 to-teal-950/95 border-2 border-emerald-500/40 text-emerald-50 rounded-bl-sm'
                      : 'bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 font-semibold rounded-br-sm shadow-amber-500/20'
                  }`}
                >
                  {/* Amaran Santun jika di Luar Skop */}
                  {msg.isOutOfScope && (
                    <div className="flex items-center gap-1.5 mb-2 px-2.5 py-1 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-200 text-xs font-bold">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-300 flex-shrink-0" />
                      <span>Fokus Pengembaraan: Sirah Nabi Muhammad SAW</span>
                    </div>
                  )}

                  <p className="whitespace-pre-line font-medium text-sm md:text-base">
                    {msg.text}
                  </p>

                  <div className="mt-2 flex items-center justify-between text-[10px] opacity-75">
                    <span>{msg.timestamp}</span>

                    {/* Butang Audio untuk Mesej Ustaz */}
                    {isUstaz && (
                      <button
                        onClick={() => handleSpeak(msg.id, msg.text)}
                        className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-700 text-amber-300 font-bold border border-emerald-600/50 ml-2"
                        aria-label={isSpeakingThis ? 'Hentikan bacaan' : 'Dengar jawapan dengan suara'}
                      >
                        {isSpeakingThis ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                            <span>Henti</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-amber-300" />
                            <span>Dengar</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Penunjuk Memuatkan (Ustaz Cilik Sedang Berfikir) */}
          {isLoading && (
            <div className="flex gap-3 items-end justify-start">
              <div className="w-10 h-10 rounded-2xl bg-amber-400 border-2 border-amber-300 flex items-center justify-center shadow-md animate-bounce">
                <span className="text-xs font-black text-emerald-950">UC</span>
              </div>
              <div className="bg-emerald-900/80 border border-emerald-500/40 rounded-3xl rounded-bl-sm p-4 shadow-lg text-emerald-200 flex items-center gap-2">
                <span className="text-xs font-semibold">Ustaz Cilik sedang berfikir</span>
                <span className="flex gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Bahagian Bawah: Soalan Cadangan & Kotak Input */}
        <div className="w-full bg-emerald-950/80 border border-emerald-700/60 rounded-3xl p-3 shadow-2xl backdrop-blur-md">
          {/* Baris Cip Soalan Pantas */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-2 scrollbar-none">
            <span className="text-[11px] font-bold text-amber-300 flex-shrink-0 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              <span>Soalan Pantas:</span>
            </span>
            {activeSuggestions.map((sug, sIdx) => (
              <button
                key={sIdx}
                onClick={() => handleSendMessage(sug)}
                className="flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full bg-emerald-900/90 hover:bg-emerald-800 text-emerald-100 hover:text-white border border-emerald-700/70 hover:border-amber-400 transition-all hover:scale-105"
              >
                {sug}
              </button>
            ))}
          </div>

          {/* Kotak Menaip Soalan Kanak-Kanak */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Tanya soalan tentang Wahyu Pertama atau Sirah Nabi SAW..."
              className="flex-1 bg-emerald-900/60 border border-emerald-700 rounded-2xl px-4 py-3 text-sm text-white placeholder-emerald-300/60 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition"
              disabled={isLoading}
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 disabled:opacity-40 text-emerald-950 font-black shadow-lg shadow-amber-500/20 transition-transform active:scale-95 flex items-center justify-center flex-shrink-0"
              aria-label="Hantar soalan"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <p className="text-[10px] text-emerald-300/70 text-center mt-2">
            Ustaz Cilik AI membimbing pemahaman Sirah berpandukan fakta yang sahih dan adab Islam.
          </p>
        </div>
      </main>
    </div>
  );
};
