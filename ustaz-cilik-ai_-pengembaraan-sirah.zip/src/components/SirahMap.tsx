import React, { useState } from 'react';
import { SIRAH_TOPICS, SirahTopic } from '../logic/sirahData';
import { UstazCilikMascot } from './UstazCilikMascot';
import {
  ArrowLeft,
  Mountain,
  Compass,
  MessageSquare,
  Sparkles,
  ChevronRight,
  BookOpen,
  Award,
} from 'lucide-react';

interface SirahMapProps {
  onBackToHome: () => void;
  onEnterGuaHira: () => void;
  onAskTopicQuestion: (topicTitle: string, question: string) => void;
  onViewAchievements: () => void;
  customMascotUrl?: string | null;
}

export const SirahMap: React.FC<SirahMapProps> = ({
  onBackToHome,
  onEnterGuaHira,
  onAskTopicQuestion,
  onViewAchievements,
  customMascotUrl,
}) => {
  const [selectedTopic, setSelectedTopic] = useState<SirahTopic>(SIRAH_TOPICS[1]); // Default Wahyu Pertama

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between p-4 selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Atas Peta */}
      <header className="max-w-6xl mx-auto w-full flex items-center justify-between py-3 border-b border-emerald-800/60 z-10">
        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Laman Utama</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] md:text-xs font-bold text-amber-300 tracking-wider uppercase flex items-center justify-center gap-1">
            <Compass className="w-3.5 h-3.5 text-amber-400" />
            <span>Peta Pengembaraan Sirah</span>
          </span>
          <h2 className="text-sm md:text-lg font-black text-white">
            6 Stesen Riwayat Hidup Nabi Muhammad SAW
          </h2>
        </div>

        <button
          onClick={onViewAchievements}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold"
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Lencana</span>
        </button>
      </header>

      {/* Kandungan Peta Pengembaraan */}
      <main className="max-w-6xl mx-auto w-full flex-1 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Kolum Kiri: 6 Stesen Pengembaraan */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-emerald-200 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Pilih Stesen Pengembaraan:</span>
            </h3>
            <span className="text-xs text-amber-300 font-semibold">
              Misi Utama: Wahyu Pertama
            </span>
          </div>

          <div className="space-y-3">
            {SIRAH_TOPICS.map((topic, idx) => {
              const isSelected = selectedTopic.id === topic.id;
              const isMainMission = topic.id === 'wahyu_pertama';

              return (
                <div
                  key={topic.id}
                  onClick={() => setSelectedTopic(topic)}
                  className={`w-full text-left p-4 rounded-3xl border-2 transition-all duration-200 cursor-pointer relative overflow-hidden flex items-center justify-between gap-4 ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-800 to-teal-850 border-amber-400 shadow-xl scale-[1.01]'
                      : 'bg-emerald-950/70 border-emerald-800/80 hover:bg-emerald-900/60 hover:border-emerald-600'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm flex-shrink-0 shadow-md ${
                        isMainMission
                          ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 text-emerald-950 ring-2 ring-amber-300 animate-pulse'
                          : isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'bg-emerald-900 text-emerald-300'
                      }`}
                    >
                      {idx + 1}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm md:text-base font-bold text-white">
                          {topic.title}
                        </h4>
                        {isMainMission && (
                          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-emerald-950 shadow-sm">
                            Fokus Utama
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-emerald-300/90 font-medium mt-0.5">
                        {topic.period}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {isMainMission ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEnterGuaHira();
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs shadow-md transition hover:scale-105"
                      >
                        Buka Portal
                      </button>
                    ) : (
                      <ChevronRight className="w-5 h-5 text-emerald-400" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Kolum Kanan: Perincian Stesen Terpilih & Soalan Pilihan */}
        <div className="lg:col-span-5 bg-gradient-to-br from-emerald-900/95 via-teal-900/95 to-emerald-950/95 border-2 border-amber-400/60 rounded-3xl p-6 shadow-2xl backdrop-blur-md">
          {/* Tajuk Stesen */}
          <div className="flex items-center justify-between border-b border-emerald-800/60 pb-3 mb-4">
            <div>
              <span className="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
                Stesen Terpilih
              </span>
              <h3 className="text-xl font-black text-white">
                {selectedTopic.title}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>

          <p className="text-xs md:text-sm text-emerald-100 leading-relaxed mb-4">
            {selectedTopic.description}
          </p>

          {/* Fakta Kunci */}
          <div className="bg-emerald-950/80 border border-emerald-700/60 rounded-2xl p-3.5 mb-5">
            <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block mb-1">
              Fakta Menarik Sirah:
            </span>
            <p className="text-xs text-emerald-100 font-medium">
              &ldquo;{selectedTopic.keyFact}&rdquo;
            </p>
          </div>

          {/* Soalan Cadangan untuk Kanak-Kanak */}
          <div className="mb-5">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider block mb-2.5">
              Soalan Cadangan untuk Ditanya:
            </span>
            <div className="space-y-2">
              {selectedTopic.sampleQuestions.map((sq, sIdx) => (
                <button
                  key={sIdx}
                  onClick={() => onAskTopicQuestion(selectedTopic.title, sq)}
                  className="w-full text-left p-2.5 rounded-xl bg-emerald-800/70 hover:bg-emerald-700/90 border border-emerald-600/50 text-xs text-white font-medium flex items-center justify-between gap-2 transition hover:scale-[1.01]"
                >
                  <span>{sq}</span>
                  <MessageSquare className="w-3.5 h-3.5 text-amber-300 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Tindakan Utama Stesen */}
          {selectedTopic.id === 'wahyu_pertama' ? (
            <button
              onClick={onEnterGuaHira}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 font-black text-sm shadow-xl shadow-amber-500/30 transition hover:scale-105 flex items-center justify-center gap-2"
            >
              <Mountain className="w-5 h-5" />
              <span>Masuk ke Portal Gua Hira&apos; (Misi 1)</span>
            </button>
          ) : (
            <button
              onClick={() =>
                onAskTopicQuestion(
                  selectedTopic.title,
                  `Boleh Ustaz Cilik ceritakan ringkasan tentang ${selectedTopic.title}?`
                )
              }
              className="w-full py-3 rounded-2xl bg-teal-700 hover:bg-teal-600 text-white font-bold text-xs md:text-sm border border-teal-500 transition flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-amber-300" />
              <span>Tanya Ustaz Cilik tentang Stesen Ini</span>
            </button>
          )}

          {/* Maskot Mini */}
          <div className="mt-4 pt-3 border-t border-emerald-800/60 flex items-center gap-3">
            <UstazCilikMascot
              expression="welcoming"
              size="sm"
              customImageUrl={customMascotUrl}
            />
            <p className="text-[11px] text-emerald-200">
              Pilih mana-mana stesen untuk meneroka riwayat hidup Nabi Muhammad SAW bersama Ustaz Cilik!
            </p>
          </div>
        </div>
      </main>

      <footer className="max-w-6xl mx-auto w-full py-2 text-center text-xs text-emerald-300/60">
        Pendidikan Islam Tahun 3 • Peta Kronologi Sirah Nabawiyyah
      </footer>
    </div>
  );
};
