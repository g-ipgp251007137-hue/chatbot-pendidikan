import React, { useState } from 'react';
import { InfographicSection } from '../logic/sirahData';
import { UstazCilikMascot, MascotExpression } from './UstazCilikMascot';
import { speechService } from '../utils/speech';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  CheckCircle,
  HelpCircle,
  Award,
  Sparkles,
  BookOpen,
  Mountain,
  Scroll,
  HeartHandshake,
  Maximize2,
  ZoomIn,
} from 'lucide-react';

interface InfographicViewerProps {
  sections: InfographicSection[];
  onBack: () => void;
  onAskAboutSection: (topic: string, question: string) => void;
  onTakeQuiz: () => void;
  onSectionRead: (sectionId: string) => void;
  readSectionIds: string[];
  customInfographicUrl?: string | null;
  customMascotUrl?: string | null;
}

export const InfographicViewer: React.FC<InfographicViewerProps> = ({
  sections,
  onBack,
  onAskAboutSection,
  onTakeQuiz,
  onSectionRead,
  readSectionIds,
  customInfographicUrl,
  customMascotUrl,
}) => {
  const [activeSectionIndex, setActiveSectionIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [mascotExp, setMascotExp] = useState<MascotExpression>('explaining');
  const [showFullImageModal, setShowFullImageModal] = useState(false);

  const currentSection = sections[activeSectionIndex] || sections[0];
  const isRead = readSectionIds.includes(currentSection.id);

  const getSectionIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className="w-6 h-6 text-amber-300" />;
      case 'Mountain':
        return <Mountain className="w-6 h-6 text-amber-300" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-amber-300" />;
      case 'Scroll':
        return <Scroll className="w-6 h-6 text-amber-300" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-6 h-6 text-amber-300" />;
      default:
        return <BookOpen className="w-6 h-6 text-amber-300" />;
    }
  };

  const handleSpeakCurrent = () => {
    if (speechService.isSpeaking()) {
      speechService.stop();
      setIsSpeaking(false);
      setMascotExp('explaining');
    } else {
      setIsSpeaking(true);
      setMascotExp('explaining');
      speechService.speak(
        `${currentSection.title}. ${currentSection.summary}. ${currentSection.explanation}`,
        () => {
          setIsSpeaking(false);
          setMascotExp('excited');
        }
      );
    }
  };

  const handleMarkUnderstood = () => {
    onSectionRead(currentSection.id);
    setMascotExp('congratulating');
    // Jika belum tamat, bergerak ke bahagian seterusnya secara lembut
    if (activeSectionIndex < sections.length - 1) {
      setTimeout(() => {
        setActiveSectionIndex((prev) => prev + 1);
        setMascotExp('explaining');
      }, 700);
    }
  };

  const handleAskQuestion = () => {
    speechService.stop();
    onAskAboutSection(currentSection.title, `Boleh Ustaz Cilik terangkan lebih lanjut tentang ${currentSection.title}?`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Atas */}
      <header className="w-full max-w-6xl mx-auto px-4 py-4 flex items-center justify-between border-b border-emerald-800/50">
        <button
          onClick={() => {
            speechService.stop();
            onBack();
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Kembali ke Portal</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] md:text-xs font-bold text-amber-300 tracking-wider uppercase">
            Bahan Pembelajaran Rasmi
          </span>
          <h2 className="text-sm md:text-lg font-black text-white">
            Infografik Interaktif: Wahyu Pertama
          </h2>
        </div>

        <button
          onClick={onTakeQuiz}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/30 hover:bg-amber-500/40 text-amber-300 border border-amber-400/50 font-bold text-xs md:text-sm transition shadow-sm"
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Uji Kefahaman</span>
        </button>
      </header>

      {/* Kandungan Infografik Utama */}
      <main className="max-w-6xl mx-auto px-4 py-6 w-full flex-1 flex flex-col items-center">
        {/* Butang Navigasi Bahagian Infografik */}
        <div className="w-full flex items-center justify-start md:justify-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-thin">
          {sections.map((sec, idx) => {
            const active = idx === activeSectionIndex;
            const completed = readSectionIds.includes(sec.id);
            return (
              <button
                key={sec.id}
                onClick={() => {
                  speechService.stop();
                  setIsSpeaking(false);
                  setActiveSectionIndex(idx);
                }}
                className={`flex-shrink-0 flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs md:text-sm font-bold transition-all duration-200 border ${
                  active
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 border-amber-300 shadow-lg scale-105'
                    : completed
                    ? 'bg-emerald-800/80 text-emerald-200 border-emerald-600/60 hover:bg-emerald-700'
                    : 'bg-emerald-950/70 text-emerald-300 border-emerald-800 hover:bg-emerald-900/80'
                }`}
              >
                {completed && <CheckCircle className={`w-3.5 h-3.5 ${active ? 'text-emerald-950' : 'text-emerald-400'}`} />}
                <span>{sec.title.split('.')[0] || idx + 1}</span>
                <span className="truncate max-w-[120px] hidden md:inline">
                  {sec.title.split('.')[1] || sec.title}
                </span>
              </button>
            );
          })}
        </div>

        {/* Panel Kad Infografik Terperinci */}
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Kad Maklumat Utama */}
          <div className="lg:col-span-8 bg-gradient-to-br from-emerald-900/90 via-teal-900/90 to-emerald-950/90 border-2 border-amber-400/50 rounded-3xl p-6 shadow-2xl backdrop-blur-md relative overflow-hidden">
            {/* Lencana Sorotan */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center shadow-md">
                  {getSectionIcon(currentSection.iconName)}
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-black text-white">
                    {currentSection.title}
                  </h3>
                  <p className="text-xs md:text-sm text-amber-200 font-semibold">
                    {currentSection.subtitle}
                  </p>
                </div>
              </div>

              {/* Butang Dengar Suara Bahagian Ini */}
              <button
                onClick={handleSpeakCurrent}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-emerald-100 border border-emerald-600 text-xs font-semibold shadow-sm"
              >
                {isSpeaking ? (
                  <>
                    <VolumeX className="w-4 h-4 text-amber-300 animate-pulse" />
                    <span>Henti Suara</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4 text-amber-300" />
                    <span>Baca Suara</span>
                  </>
                )}
              </button>
            </div>

            {/* Kotak Ringkasan Utama */}
            <div className="bg-emerald-950/70 p-4 rounded-2xl border border-emerald-700/60 mb-5">
              <p className="text-sm md:text-base text-emerald-100 font-medium leading-relaxed">
                {currentSection.summary}
              </p>
            </div>

            {/* Fakta Utama & Poin Penting Murid Tahun 3 */}
            <div className="mb-6">
              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Poin Penting untuk Diingati:</span>
              </h4>
              <ul className="space-y-2.5">
                {currentSection.points.map((pt, pIdx) => (
                  <li
                    key={pIdx}
                    className="flex items-start gap-2.5 text-xs md:text-sm text-emerald-50 bg-emerald-900/40 p-2.5 rounded-xl border border-emerald-800/40"
                  >
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-emerald-950 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      {pIdx + 1}
                    </span>
                    <span className="leading-snug">{pt}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Penerangan Mesra Kanak-Kanak oleh Ustaz Cilik */}
            <div className="bg-amber-400/10 border border-amber-400/40 rounded-2xl p-4 mb-6">
              <div className="flex items-center gap-2 mb-1.5 text-amber-300 text-xs font-bold">
                <span>Pesan Ustaz Cilik:</span>
              </div>
              <p className="text-xs md:text-sm text-amber-100 leading-relaxed italic">
                &ldquo;{currentSection.explanation}&rdquo;
              </p>
            </div>

            {/* Butang Tindakan Bawah */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-emerald-800/60">
              <button
                onClick={handleAskQuestion}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-800/80 hover:bg-teal-700 text-white font-bold text-xs md:text-sm border border-teal-600 transition shadow-sm"
              >
                <HelpCircle className="w-4 h-4 text-amber-300" />
                <span>Saya Mahu Tanya Bahagian Ini</span>
              </button>

              <button
                onClick={handleMarkUnderstood}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-black text-xs md:text-sm transition shadow-md ${
                  isRead
                    ? 'bg-emerald-600 text-white border border-emerald-400'
                    : 'bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 border border-amber-300 hover:scale-105'
                }`}
              >
                <CheckCircle className="w-4 h-4" />
                <span>{isRead ? 'Sudah Faham ✓' : 'Saya Faham! Seterusnya →'}</span>
              </button>
            </div>
          </div>

          {/* Kolum Kanan: Maskot & Pratonton Infografik Visual */}
          <div className="lg:col-span-4 flex flex-col items-center gap-4">
            {/* Maskot Interaktif Ustaz Cilik */}
            <div className="w-full bg-emerald-900/60 border border-emerald-700/50 rounded-3xl p-4 flex flex-col items-center shadow-xl">
              <UstazCilikMascot
                expression={mascotExp}
                size="md"
                isSpeaking={isSpeaking}
                bubbleText={`Bahagian ${activeSectionIndex + 1}: ${currentSection.highlightText}`}
                customImageUrl={customMascotUrl}
              />
              <span className="text-[11px] text-emerald-200 mt-2 font-medium text-center">
                Ustaz Cilik sedia menerangkan fakta Sirah dengan tepat!
              </span>
            </div>

            {/* Kad Infografik Gambar Guru (atau Ilustrasi Terbina Dalam) */}
            <div className="w-full bg-emerald-950/80 border border-emerald-800 rounded-3xl p-4 flex flex-col items-center shadow-lg relative group">
              <div className="w-full flex items-center justify-between text-xs font-semibold text-emerald-200 mb-2">
                <span>Visual Infografik</span>
                <button
                  onClick={() => setShowFullImageModal(true)}
                  className="flex items-center gap-1 text-[11px] text-amber-300 hover:underline"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Besarkan</span>
                </button>
              </div>

              {customInfographicUrl ? (
                <div
                  onClick={() => setShowFullImageModal(true)}
                  className="w-full h-44 rounded-2xl overflow-hidden border border-emerald-700/60 cursor-pointer relative"
                >
                  <img
                    src={customInfographicUrl}
                    alt="Infografik Wahyu Pertama yang dimuat naik oleh guru"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-emerald-950/20 group-hover:bg-transparent transition-colors flex items-center justify-center">
                    <ZoomIn className="w-6 h-6 text-white drop-shadow-md opacity-80" />
                  </div>
                </div>
              ) : (
                /* Poster Infografik Vektor Ilustrasi Standard */
                <div
                  onClick={() => setShowFullImageModal(true)}
                  className="w-full h-44 rounded-2xl bg-gradient-to-br from-emerald-800 to-teal-900 p-3 border border-emerald-600/50 cursor-pointer flex flex-col justify-between shadow-inner"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold bg-amber-400 text-emerald-950 px-2 py-0.5 rounded-full">
                      Wahyu Pertama
                    </span>
                    <span className="text-[10px] text-emerald-200">Gua Hira&apos;</span>
                  </div>
                  <div className="text-center my-auto">
                    <p className="text-lg font-black text-amber-300 tracking-wider">
                      IQRA&apos; — BACALAH!
                    </p>
                    <p className="text-xs text-amber-100 font-serif font-bold mt-0.5">
                      Surah Al-&apos;Alaq (Ayat 1-5)
                    </p>
                    <p className="text-[11px] text-emerald-200 mt-1 font-medium italic">
                      &quot;Bacalah dengan nama Tuhanmu yang menciptakan&quot;
                    </p>
                  </div>
                  <div className="flex justify-between text-[10px] text-emerald-300">
                    <span>17 Ramadan</span>
                    <span>Usia 40 Tahun</span>
                  </div>
                </div>
              )}

              <p className="text-[11px] text-emerald-300/80 text-center mt-2">
                Tekan untuk melihat carta infografik penuh dalam paparan skrin besar.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Modal Zum Infografik Penuh */}
      {showFullImageModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setShowFullImageModal(false)}
        >
          <div
            className="relative max-w-4xl w-full bg-emerald-950 border-2 border-amber-400 rounded-3xl p-6 shadow-2xl text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-emerald-800">
              <h3 className="text-lg font-black text-amber-300">
                Paparan Penuh: Infografik Wahyu Pertama
              </h3>
              <button
                onClick={() => setShowFullImageModal(false)}
                className="w-8 h-8 rounded-full bg-emerald-800 hover:bg-emerald-700 text-white flex items-center justify-center text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="my-4 max-h-[70vh] overflow-y-auto rounded-2xl bg-emerald-900/40 p-4 border border-emerald-700 flex flex-col items-center">
              {customInfographicUrl ? (
                <img
                  src={customInfographicUrl}
                  alt="Infografik Wahyu Pertama Penuh"
                  className="max-h-[60vh] object-contain rounded-xl shadow-lg"
                />
              ) : (
                <div className="w-full text-center space-y-4 py-6">
                  <div className="inline-block bg-amber-400 text-emerald-950 font-black text-sm px-4 py-1 rounded-full">
                    KANDUNGAN RASMI SIRAH TAHUN 3
                  </div>
                  <h4 className="text-2xl font-bold text-white">
                    Peristiwa Wahyu Pertama di Gua Hira&apos;
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-left">
                    {sections.map((s) => (
                      <div key={s.id} className="bg-emerald-950/80 p-3.5 rounded-xl border border-emerald-700">
                        <p className="font-bold text-amber-300 text-sm">{s.title}</p>
                        <p className="text-xs text-emerald-100 mt-1">{s.summary}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowFullImageModal(false)}
                className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-xs"
              >
                Tutup Paparan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Kaki Halaman */}
      <footer className="w-full max-w-6xl mx-auto px-4 py-3 text-center text-xs text-emerald-300/60 border-t border-emerald-800/40">
        Pendidikan Islam Tahun 3 • Infografik Disahkan Guru
      </footer>
    </div>
  );
};
