import React from 'react';

export type MascotExpression =
  | 'welcoming'
  | 'explaining'
  | 'listening'
  | 'thinking'
  | 'encouraging'
  | 'excited'
  | 'helper'
  | 'congratulating'
  | 'action';

interface UstazCilikMascotProps {
  expression?: MascotExpression;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  bubbleText?: string;
  isSpeaking?: boolean;
  isThinking?: boolean;
  customImageUrl?: string | null;
  className?: string;
}

export const UstazCilikMascot: React.FC<UstazCilikMascotProps> = ({
  expression = 'welcoming',
  size = 'md',
  bubbleText,
  isSpeaking = false,
  isThinking = false,
  customImageUrl,
  className = '',
}) => {
  const sizeMap = {
    sm: 'w-24 h-28',
    md: 'w-36 h-44',
    lg: 'w-52 h-64',
    xl: 'w-72 h-84',
  };

  // Sekiranya guru memuat naik imej maskot rasmi, gunakan imej tersebut
  if (customImageUrl) {
    return (
      <div className={`relative flex flex-col items-center ${className}`}>
        {bubbleText && (
          <div className="mb-2 max-w-xs rounded-2xl bg-white px-4 py-2.5 text-xs font-medium text-emerald-950 shadow-lg ring-2 ring-emerald-400 border border-emerald-100 animate-bounce duration-1000">
            {bubbleText}
          </div>
        )}
        <div className={`relative overflow-hidden rounded-3xl border-4 border-amber-300 shadow-2xl bg-gradient-to-b from-emerald-50 to-emerald-100 ${sizeMap[size]}`}>
          <img
            src={customImageUrl}
            alt="Maskot Ustaz Cilik"
            className="w-full h-full object-cover"
          />
          {isThinking && (
            <div className="absolute inset-0 bg-emerald-950/30 flex items-center justify-center">
              <span className="flex space-x-1.5 bg-white/90 px-3 py-1.5 rounded-full shadow-md">
                <span className="w-2 h-2 bg-emerald-600 rounded-full animate-ping" />
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="w-2 h-2 bg-emerald-400 rounded-full" />
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Parameter Visual Berdasarkan Ekspresi
  const getExpressionDetails = () => {
    switch (expression) {
      case 'excited':
      case 'congratulating':
        return {
          eyebrows: 'M 35 48 Q 42 43 50 49 M 70 49 Q 78 43 85 48',
          eyes: (
            <>
              {/* Mata berbentuk bintang gembira */}
              <ellipse cx="44" cy="58" rx="7" ry="8" fill="#1e293b" />
              <circle cx="42" cy="55" r="3" fill="#ffffff" />
              <circle cx="46" cy="61" r="1.5" fill="#ffffff" />
              <ellipse cx="76" cy="58" rx="7" ry="8" fill="#1e293b" />
              <circle cx="74" cy="55" r="3" fill="#ffffff" />
              <circle cx="78" cy="61" r="1.5" fill="#ffffff" />
            </>
          ),
          mouth: 'M 48 76 Q 60 92 72 76 Z', // Senyuman luas terbuka
          mouthFill: '#be123c',
          hands: (
            <>
              {/* Tangan melambai gembira ke atas */}
              <path d="M 24 100 Q 12 85 18 70" stroke="#fde047" strokeWidth="6" strokeLinecap="round" />
              <circle cx="18" cy="68" r="6" fill="#fed7aa" />
              <path d="M 96 100 Q 108 85 102 70" stroke="#fde047" strokeWidth="6" strokeLinecap="round" />
              <circle cx="102" cy="68" r="6" fill="#fed7aa" />
            </>
          ),
          auraColor: 'from-amber-200/50 to-emerald-200/40',
        };
      case 'thinking':
        return {
          eyebrows: 'M 35 46 Q 42 42 50 48 M 70 50 Q 78 46 85 52',
          eyes: (
            <>
              <ellipse cx="45" cy="56" rx="6" ry="7" fill="#1e293b" />
              <circle cx="46" cy="53" r="2.5" fill="#ffffff" />
              <ellipse cx="77" cy="56" rx="6" ry="7" fill="#1e293b" />
              <circle cx="78" cy="53" r="2.5" fill="#ffffff" />
            </>
          ),
          mouth: 'M 52 79 Q 60 76 68 80', // Mulut berfikir sedikit herot comel
          mouthFill: 'none',
          hands: (
            <>
              {/* Jari menyentuh dagu berfikir */}
              <path d="M 96 110 Q 86 96 74 86" stroke="#ffffff" strokeWidth="7" strokeLinecap="round" />
              <circle cx="72" cy="84" r="6" fill="#fed7aa" />
            </>
          ),
          auraColor: 'from-blue-200/40 to-teal-200/30',
        };
      case 'helper':
        return {
          eyebrows: 'M 36 50 Q 42 47 50 51 M 70 51 Q 78 47 84 50',
          eyes: (
            <>
              <ellipse cx="44" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="43" cy="55" r="2.5" fill="#ffffff" />
              <ellipse cx="76" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="75" cy="55" r="2.5" fill="#ffffff" />
            </>
          ),
          mouth: 'M 50 78 Q 60 84 70 78', // Senyuman lembut menenangkan
          mouthFill: 'none',
          hands: (
            <>
              {/* Tangan menghulur bantuan dengan sopan */}
              <path d="M 22 104 Q 38 108 50 102" stroke="#ffffff" strokeWidth="7" strokeLinecap="round" />
              <circle cx="53" cy="101" r="6" fill="#fed7aa" />
            </>
          ),
          auraColor: 'from-emerald-200/40 to-yellow-100/40',
        };
      case 'explaining':
      case 'action':
        return {
          eyebrows: 'M 35 47 Q 42 42 50 48 M 70 48 Q 78 42 85 47',
          eyes: (
            <>
              <ellipse cx="44" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="42" cy="55" r="2.5" fill="#ffffff" />
              <circle cx="46" cy="61" r="1.2" fill="#ffffff" />
              <ellipse cx="76" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="74" cy="55" r="2.5" fill="#ffffff" />
              <circle cx="78" cy="61" r="1.2" fill="#ffffff" />
            </>
          ),
          mouth: isSpeaking
            ? 'M 50 75 Q 60 88 70 75 Z'
            : 'M 50 76 Q 60 86 70 76', // Menerangkan
          mouthFill: isSpeaking ? '#be123c' : 'none',
          hands: (
            <>
              {/* Tangan menunjukkan ke arah skrin / buku */}
              <path d="M 96 102 Q 112 88 116 75" stroke="#ffffff" strokeWidth="7" strokeLinecap="round" />
              <circle cx="116" cy="73" r="6" fill="#fed7aa" />
            </>
          ),
          auraColor: 'from-emerald-200/50 to-teal-200/40',
        };
      case 'listening':
        return {
          eyebrows: 'M 36 49 Q 43 45 50 50 M 70 50 Q 77 45 84 49',
          eyes: (
            <>
              <ellipse cx="44" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="43" cy="55" r="2.5" fill="#ffffff" />
              <ellipse cx="76" cy="58" rx="6.5" ry="7.5" fill="#1e293b" />
              <circle cx="75" cy="55" r="2.5" fill="#ffffff" />
            </>
          ),
          mouth: 'M 52 78 Q 60 84 68 78',
          mouthFill: 'none',
          hands: null,
          auraColor: 'from-teal-100/50 to-emerald-100/50',
        };
      case 'welcoming':
      default:
        return {
          eyebrows: 'M 35 48 Q 42 43 50 49 M 70 49 Q 78 43 85 48',
          eyes: (
            <>
              <ellipse cx="44" cy="58" rx="7" ry="8" fill="#1e293b" />
              <circle cx="42" cy="54" r="3" fill="#ffffff" />
              <circle cx="46" cy="61" r="1.5" fill="#ffffff" />
              <ellipse cx="76" cy="58" rx="7" ry="8" fill="#1e293b" />
              <circle cx="74" cy="54" r="3" fill="#ffffff" />
              <circle cx="78" cy="61" r="1.5" fill="#ffffff" />
            </>
          ),
          mouth: 'M 49 76 Q 60 89 71 76 Z', // Senyuman ceria menyambut
          mouthFill: '#be123c',
          hands: (
            <>
              {/* Lambai salam sopan */}
              <path d="M 96 102 Q 112 85 108 72" stroke="#ffffff" strokeWidth="7" strokeLinecap="round" />
              <circle cx="108" cy="70" r="6" fill="#fed7aa" />
            </>
          ),
          auraColor: 'from-emerald-300/40 via-amber-200/30 to-emerald-200/40',
        };
    }
  };

  const details = getExpressionDetails();

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* Gelembung Dialog Santun */}
      {bubbleText && (
        <div className="mb-2 max-w-xs md:max-w-sm rounded-2xl bg-white px-4 py-2.5 text-xs md:text-sm font-semibold text-emerald-950 shadow-xl ring-2 ring-emerald-500/30 border border-emerald-100 relative z-20">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <p className="leading-snug">{bubbleText}</p>
          </div>
          {/* Ekor gelembung */}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-white rotate-45 border-r border-b border-emerald-100 shadow-sm" />
        </div>
      )}

      {/* Kontena Watak 3D Kartun */}
      <div className={`relative ${sizeMap[size]} transition-transform duration-500 hover:scale-105`}>
        {/* Aura Bercahaya Lembut (Halus & Sopan) */}
        <div
          className={`absolute -inset-2 rounded-full bg-gradient-to-tr ${details.auraColor} blur-xl opacity-75 animate-pulse pointer-events-none`}
        />

        {/* SVG Lengkap Ustaz Cilik */}
        <svg
          viewBox="0 0 120 145"
          className="w-full h-full drop-shadow-xl overflow-visible"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Gradien Baju Melayu Putih Bersih */}
            <linearGradient id="bajuGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="60%" stopColor="#f8fafc" />
              <stop offset="100%" stopColor="#e2e8f0" />
            </linearGradient>

            {/* Gradien Selempang Hijau Zamrud */}
            <linearGradient id="sashGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="50%" stopColor="#059669" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>

            {/* Gradien Songkok/Kopiah Putih dengan corak emas */}
            <linearGradient id="kopiahGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="85%" stopColor="#f1f5f9" />
              <stop offset="100%" stopColor="#e2e8f0" />
            </linearGradient>

            {/* Gradien Kulit Comel & Hangat */}
            <radialGradient id="skinGradient" cx="45%" cy="40%" r="55%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="70%" stopColor="#fed7aa" />
              <stop offset="100%" stopColor="#fbcfe8" />
            </radialGradient>
          </defs>

          {/* Bayang tapak kaki */}
          <ellipse cx="60" cy="140" rx="36" ry="6" fill="#064e3b" opacity="0.15" />

          {/* BADAN & BAJU MELAYU PUTIH */}
          <g id="body">
            {/* Badan Baju Melayu */}
            <path
              d="M 28 92 C 24 105 24 125 24 135 C 24 137 96 137 96 135 C 96 125 96 105 92 92 Z"
              fill="url(#bajuGradient)"
              stroke="#cbd5e1"
              strokeWidth="1.5"
            />
            {/* Kolar Cekak Musang Baju Melayu */}
            <path
              d="M 46 88 L 60 97 L 74 88 L 60 84 Z"
              fill="#ffffff"
              stroke="#94a3b8"
              strokeWidth="1"
            />
            {/* Butang Baju Melayu Emas */}
            <circle cx="60" cy="99" r="1.5" fill="#f59e0b" />
            <circle cx="60" cy="107" r="1.5" fill="#f59e0b" />
            <circle cx="60" cy="115" r="1.5" fill="#f59e0b" />

            {/* SELEMPANG HIJAU ZAMRUD (Melintang dari bahu kanan ke pinggang kiri) */}
            <path
              d="M 76 90 L 89 97 L 44 136 L 31 133 Z"
              fill="url(#sashGradient)"
              stroke="#047857"
              strokeWidth="0.8"
            />
            {/* Garis Emas Halus pada Selempang */}
            <path
              d="M 78 92 L 35 134"
              stroke="#fbbf24"
              strokeWidth="1"
              strokeDasharray="2 2"
            />
            <path
              d="M 86 96 L 42 136"
              stroke="#fbbf24"
              strokeWidth="1"
              strokeDasharray="2 2"
            />
          </g>

          {/* LENGAN BAJU & TANGAN */}
          <g id="arms">
            {/* Lengan Kiri Statik */}
            <path
              d="M 28 94 Q 18 108 24 122"
              stroke="#ffffff"
              strokeWidth="8"
              strokeLinecap="round"
              fill="none"
            />
            <circle cx="25" cy="122" r="5" fill="#fed7aa" />

            {/* Tangan Ekspresi Kanan */}
            {details.hands}
          </g>

          {/* KEPALA & MUKA */}
          <g id="head">
            {/* Leher */}
            <rect x="52" y="76" width="16" height="14" rx="4" fill="#fed7aa" />

            {/* Telinga */}
            <circle cx="28" cy="62" r="7" fill="#fed7aa" />
            <circle cx="28" cy="62" r="4" fill="#fdba74" opacity="0.6" />
            <circle cx="92" cy="62" r="7" fill="#fed7aa" />
            <circle cx="92" cy="62" r="4" fill="#fdba74" opacity="0.6" />

            {/* Bentuk Muka Comel Kanak-Kanak */}
            <circle cx="60" cy="62" r="32" fill="url(#skinGradient)" stroke="#fed7aa" strokeWidth="1" />

            {/* Pipi Kemerahan (Blush) Comel */}
            <circle cx="36" cy="66" r="6" fill="#f43f5e" opacity="0.25" />
            <circle cx="84" cy="66" r="6" fill="#f43f5e" opacity="0.25" />

            {/* Rambut Halus Tepi Kopiah */}
            <path
              d="M 28 52 Q 25 42 32 36 Q 30 52 35 56"
              fill="#1e293b"
            />
            <path
              d="M 92 52 Q 95 42 88 36 Q 90 52 85 56"
              fill="#1e293b"
            />

            {/* Kening */}
            <path
              d={details.eyebrows}
              stroke="#334155"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
            />

            {/* Mata Ekspresif */}
            <g id="eyes">{details.eyes}</g>

            {/* Hidung Comel */}
            <path
              d="M 58 66 Q 60 68 62 66"
              stroke="#fb923c"
              strokeWidth="1.8"
              strokeLinecap="round"
              fill="none"
            />

            {/* Mulut */}
            <path
              d={details.mouth}
              stroke="#b91c1c"
              strokeWidth="2"
              strokeLinecap="round"
              fill={details.mouthFill}
            />
          </g>

          {/* KOPIAH / SONGKOK PUTIH KEMAS */}
          <g id="kopiah">
            {/* Bentuk Kopiah Melengkung */}
            <path
              d="M 30 42 C 30 18 90 18 90 42 C 84 46 36 46 30 42 Z"
              fill="url(#kopiahGradient)"
              stroke="#cbd5e1"
              strokeWidth="1.2"
            />
            {/* Jalur Hiasan Emas Halus Kopiah */}
            <path
              d="M 31 40 C 45 44 75 44 89 40"
              stroke="#d97706"
              strokeWidth="2"
              fill="none"
            />
            <circle cx="60" cy="27" r="2.5" fill="#fbbf24" />
          </g>
        </svg>

        {/* Lencana Status Pemikiran atau Bercakap */}
        {isThinking && (
          <div className="absolute -top-3 -right-2 bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold shadow-md flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-300 animate-ping" />
            Berfikir...
          </div>
        )}
        {isSpeaking && (
          <div className="absolute -top-3 -left-2 bg-amber-500 text-emerald-950 text-[10px] px-2 py-0.5 rounded-full font-bold shadow-md flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            Bercakap
          </div>
        )}
      </div>
    </div>
  );
};
