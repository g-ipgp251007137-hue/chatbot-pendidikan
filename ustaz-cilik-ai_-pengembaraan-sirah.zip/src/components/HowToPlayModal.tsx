import React from 'react';
import { Compass, BookOpen, MessageSquare, Award, CheckCircle } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
  onStart: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose, onStart }) => {
  const steps = [
    {
      num: 1,
      title: 'Mulakan Pengembaraan',
      desc: 'Masuk ke Portal Gua Hira\' untuk menyingkap rahsia peristiwa agung Wahyu Pertama.',
      icon: <Compass className="w-5 h-5 text-amber-300" />,
    },
    {
      num: 2,
      title: 'Terokai Infografik Interaktif',
      desc: 'Baca dan dengar penerangan 5 bahagian utama: Maksud Wahyu, Gua Hira\', Detik Iqra\', Surah Al-\'Alaq dan 3 Pengajaran.',
      icon: <BookOpen className="w-5 h-5 text-amber-300" />,
    },
    {
      num: 3,
      title: 'Tanya Ustaz Cilik AI',
      desc: 'Ajukan apa sahaja soalan tentang peristiwa Wahyu Pertama atau Sirah Nabi Muhammad SAW.',
      icon: <MessageSquare className="w-5 h-5 text-amber-300" />,
    },
    {
      num: 4,
      title: 'Jawab Kuiz & Raih Lencana',
      desc: 'Uji pengetahuan adik dalam kuiz ceria, kumpul 3 bintang dan tebus Sijil Peneroka Sirah!',
      icon: <Award className="w-5 h-5 text-amber-300" />,
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="relative max-w-xl w-full bg-gradient-to-br from-emerald-950 via-teal-950 to-stone-900 border-2 border-amber-400 rounded-3xl p-6 md:p-8 shadow-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-emerald-800">
          <div>
            <span className="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
              Panduan Ringkas
            </span>
            <h3 className="text-xl md:text-2xl font-black text-white">
              Cara Meneroka Pengembaraan Sirah
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800 hover:bg-emerald-700 text-white flex items-center justify-center text-sm font-bold"
            aria-label="Tutup panduan"
          >
            ✕
          </button>
        </div>

        <div className="my-6 space-y-3.5">
          {steps.map((st) => (
            <div
              key={st.num}
              className="flex items-start gap-3.5 bg-emerald-900/40 border border-emerald-700/60 p-3.5 rounded-2xl"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-800 flex items-center justify-center font-black text-amber-300 flex-shrink-0 shadow-md">
                {st.num}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>{st.title}</span>
                </h4>
                <p className="text-xs text-emerald-200 mt-0.5 leading-snug">{st.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-end pt-3 border-t border-emerald-800">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-emerald-200 text-xs font-semibold"
          >
            Tutup
          </button>
          <button
            onClick={() => {
              onClose();
              onStart();
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 font-black text-xs md:text-sm shadow-lg shadow-amber-500/20 hover:scale-105 transition"
          >
            Jom Mulakan Sekarang!
          </button>
        </div>
      </div>
    </div>
  );
};
