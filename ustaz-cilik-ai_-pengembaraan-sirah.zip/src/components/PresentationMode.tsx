import React, { useState } from 'react';
import { InfographicSection } from '../logic/sirahData';
import { UstazCilikMascot } from './UstazCilikMascot';
import { speechService } from '../utils/speech';
import {
  Maximize,
  Minimize,
  X,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Award,
  BookOpen,
  Compass,
} from 'lucide-react';

interface PresentationModeProps {
  sections: InfographicSection[];
  onExit: () => void;
  onOpenChat: () => void;
  onOpenQuiz: () => void;
  onOpenMap: () => void;
  customMascotUrl?: string | null;
}

export const PresentationMode: React.FC<PresentationModeProps> = ({
  sections,
  onExit,
  onOpenChat,
  onOpenQuiz,
  onOpenMap,
  customMascotUrl,
}) => {
  const [slideIndex, setSlideIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const currentSection = sections[slideIndex] || sections[0];

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleSpeak = () => {
    if (speechService.isSpeaking()) {
      speechService.stop();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      speechService.speak(
        `${currentSection.title}. ${currentSection.summary}. ${currentSection.explanation}`,
        () => setIsSpeaking(false)
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-emerald-950 text-white flex flex-col justify-between p-4 md:p-6 overflow-hidden select-none">
      {/* Bar Atas Pembentang */}
      <header className="w-full flex items-center justify-between border-b border-emerald-800 pb-3">
        <div className="flex items-center gap-3">
          <div className="px-3 py-1 rounded-full bg-amber-400 text-emerald-950 font-black text-xs uppercase tracking-wider">
            Mod Projektor 16:9
          </div>
          <h2 className="text-base md:text-xl font-black text-white">
            PENGEMBARAAN SIRAH: WAHYU PERTAMA
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio Suara */}
          <button
            onClick={handleSpeak}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-xs"
          >
            {isSpeaking ? <VolumeX className="w-4 h-4 animate-pulse" /> : <Volume2 className="w-4 h-4" />}
            <span>{isSpeaking ? 'Henti Suara' : 'Baca Bersuara'}</span>
          </button>

          {/* Skrin Penuh */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700"
            title="Skrin Penuh"
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>

          {/* Keluar Mod */}
          <button
            onClick={() => {
              speechService.stop();
              onExit();
            }}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-red-900/80 hover:bg-red-800 text-white font-bold text-xs"
          >
            <X className="w-4 h-4" />
            <span>Keluar</span>
          </button>
        </div>
      </header>

      {/* Slaid Utama 16:9 */}
      <main className="flex-1 my-auto max-w-6xl mx-auto w-full grid grid-cols-1 md:grid-cols-12 gap-6 items-center py-4">
        {/* Kolum Kiri: Maskot Ustaz Cilik Saiz Projektor */}
        <div className="md:col-span-4 flex flex-col items-center justify-center">
          <UstazCilikMascot
            expression={isSpeaking ? 'explaining' : 'welcoming'}
            size="xl"
            isSpeaking={isSpeaking}
            bubbleText={currentSection.highlightText}
            customImageUrl={customMascotUrl}
          />
        </div>

        {/* Kolum Kanan: Teks Kandungan Sangat Jelas & Besar */}
        <div className="md:col-span-8 bg-gradient-to-br from-emerald-900/90 to-teal-950/95 border-4 border-amber-400 rounded-3xl p-6 md:p-8 shadow-2xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-amber-300 uppercase tracking-widest">
              Bahagian {slideIndex + 1} daripada {sections.length}
            </span>
            <span className="px-3 py-1 rounded-full bg-emerald-800 border border-emerald-600 text-emerald-200 text-xs font-bold">
              Tahun 3 KSSR
            </span>
          </div>

          <h3 className="text-3xl md:text-5xl font-black text-white leading-tight">
            {currentSection.title}
          </h3>

          <p className="text-lg md:text-2xl text-amber-200 font-bold leading-snug">
            {currentSection.summary}
          </p>

          <div className="bg-emerald-950/80 p-4 rounded-2xl border border-emerald-700/80">
            <h4 className="text-xs font-bold text-amber-300 uppercase mb-2">Poin Penting:</h4>
            <ul className="space-y-2">
              {currentSection.points.map((pt, pIdx) => (
                <li key={pIdx} className="text-base md:text-lg text-emerald-100 flex items-start gap-2.5">
                  <span className="text-amber-400 font-bold">•</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </main>

      {/* Bar Kawalan Bawah Slaid Projektor */}
      <footer className="w-full max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-emerald-800 pt-3">
        {/* Butang Navigasi Slaid */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              speechService.stop();
              setSlideIndex((prev) => Math.max(0, prev - 1));
            }}
            disabled={slideIndex === 0}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-emerald-800 disabled:opacity-40 text-white font-bold text-xs md:text-sm hover:bg-emerald-700 transition"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Sebelumnya</span>
          </button>

          <span className="text-xs font-bold text-emerald-200 px-3">
            {slideIndex + 1} / {sections.length}
          </span>

          <button
            onClick={() => {
              speechService.stop();
              setSlideIndex((prev) => Math.min(sections.length - 1, prev + 1));
            }}
            disabled={slideIndex === sections.length - 1}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-emerald-800 disabled:opacity-40 text-white font-bold text-xs md:text-sm hover:bg-emerald-700 transition"
          >
            <span>Seterusnya</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Akses Pintas Pembentang ke Aktiviti Lain */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              speechService.stop();
              onOpenMap();
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-900 text-teal-100 border border-teal-700 hover:bg-teal-800 text-xs font-semibold"
          >
            <Compass className="w-3.5 h-3.5 text-amber-300" />
            <span>Peta</span>
          </button>

          <button
            onClick={() => {
              speechService.stop();
              onOpenChat();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 text-white border border-emerald-500 hover:bg-emerald-600 text-xs font-bold"
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-300" />
            <span>Buka Chatbot</span>
          </button>

          <button
            onClick={() => {
              speechService.stop();
              onOpenQuiz();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 text-emerald-950 font-black hover:bg-amber-400 text-xs"
          >
            <Award className="w-3.5 h-3.5" />
            <span>Mulakan Kuiz</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
