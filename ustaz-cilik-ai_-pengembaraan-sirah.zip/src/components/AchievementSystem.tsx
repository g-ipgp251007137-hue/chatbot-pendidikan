import React from 'react';
import { Badge } from '../logic/sirahData';
import { UstazCilikMascot } from './UstazCilikMascot';
import {
  ArrowLeft,
  Compass,
  BookOpen,
  Sparkles,
  Trophy,
  MessageCircleQuestion,
  Award,
  CheckCircle,
  Printer,
} from 'lucide-react';

interface AchievementSystemProps {
  badges: Badge[];
  onBack: () => void;
  customMascotUrl?: string | null;
}

export const AchievementSystem: React.FC<AchievementSystemProps> = ({
  badges,
  onBack,
  customMascotUrl,
}) => {
  const unlockedCount = badges.filter((b) => Boolean(b.unlockedAt)).length;
  const progressPercent = Math.round((unlockedCount / badges.length) * 100);

  const getBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass':
        return <Compass className="w-6 h-6" />;
      case 'BookOpen':
        return <BookOpen className="w-6 h-6" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6" />;
      case 'Trophy':
        return <Trophy className="w-6 h-6" />;
      case 'MessageCircleQuestion':
        return <MessageCircleQuestion className="w-6 h-6" />;
      default:
        return <Award className="w-6 h-6" />;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between p-4 selection:bg-amber-400 selection:text-emerald-950">
      <header className="max-w-5xl mx-auto w-full flex items-center justify-between py-3 border-b border-emerald-800/60">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm transition shadow-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Kembali</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] md:text-xs font-bold text-amber-300 tracking-wider uppercase">
            Pencapaian Murid Tahun 3
          </span>
          <h2 className="text-sm md:text-lg font-black text-white">
            Lencana &amp; Sijil Pengembara Sirah
          </h2>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold hover:bg-amber-500/30 transition"
        >
          <Printer className="w-4 h-4" />
          <span className="hidden sm:inline">Cetak Sijil</span>
        </button>
      </header>

      <main className="max-w-5xl mx-auto w-full flex-1 py-6 space-y-6">
        {/* Bar Kemajuan Ganjaran */}
        <div className="bg-gradient-to-r from-emerald-900/90 via-teal-900/90 to-emerald-900/90 border-2 border-amber-400/60 rounded-3xl p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-md">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">
                Tahap Pencapaian: {unlockedCount} daripada {badges.length} Lencana
              </h3>
              <p className="text-xs text-emerald-200">
                Kumpulkan semua lencana dengan membaca infografik, bertanya soalan, dan menjawab kuiz!
              </p>
            </div>
          </div>

          <div className="w-full sm:w-48">
            <div className="w-full bg-emerald-950 h-3 rounded-full overflow-hidden border border-emerald-700">
              <div
                className="bg-gradient-to-r from-amber-400 to-yellow-400 h-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <p className="text-right text-[11px] text-amber-300 font-bold mt-1">
              {progressPercent}% Lengkap
            </p>
          </div>
        </div>

        {/* Grid Lencana */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
          {badges.map((b) => {
            const isUnlocked = Boolean(b.unlockedAt);

            return (
              <div
                key={b.id}
                className={`p-4 rounded-3xl border-2 transition-all flex flex-col items-center text-center justify-between ${
                  isUnlocked
                    ? 'bg-gradient-to-b from-emerald-800 to-teal-900 border-amber-400 shadow-xl shadow-amber-500/10 scale-[1.02]'
                    : 'bg-emerald-950/60 border-emerald-900 opacity-60'
                }`}
              >
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 shadow-md ${
                    isUnlocked
                      ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 text-emerald-950 ring-2 ring-amber-300'
                      : 'bg-emerald-900 text-emerald-600'
                  }`}
                >
                  {getBadgeIcon(b.icon)}
                </div>

                <div>
                  <h4 className="font-bold text-sm text-white mb-1">{b.title}</h4>
                  <p className="text-[11px] text-emerald-200 leading-snug">
                    {b.description}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-emerald-700/50 w-full">
                  {isUnlocked ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300">
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      <span>Telah Dibuka!</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-semibold text-emerald-500">
                      Terkunci
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Kad Sijil Penghargaan Murid */}
        <div className="bg-gradient-to-b from-amber-50 to-amber-100 text-emerald-950 border-4 border-amber-400 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden print:p-8">
          <div className="absolute top-2 right-2 text-6xl opacity-10 font-serif">★</div>
          <div className="absolute bottom-2 left-2 text-6xl opacity-10 font-serif">★</div>

          <div className="text-center max-w-xl mx-auto space-y-3">
            <div className="inline-block px-4 py-1 rounded-full bg-emerald-800 text-amber-300 text-xs font-bold uppercase tracking-widest">
              Sijil Penghargaan Digital
            </div>

            <h3 className="text-2xl md:text-3xl font-black text-emerald-900 font-serif">
              PENEROKA CILIK SIRAH TAHUN 3
            </h3>

            <p className="text-xs md:text-sm text-emerald-800 leading-relaxed font-medium">
              Sijil ini mengesahkan kejayaan dan kesungguhan murid dalam meneroka peristiwa agung{' '}
              <strong>Wahyu Pertama di Gua Hira&apos;</strong> bersama Ustaz Cilik AI, berpandukan sukatan Pendidikan Islam KSSR.
            </p>

            <div className="flex items-center justify-center gap-4 py-3">
              <div className="px-4 py-2 rounded-xl bg-white border border-amber-300 shadow-sm text-center">
                <span className="text-[10px] text-emerald-700 block">Lencana Diperoleh</span>
                <span className="text-lg font-black text-emerald-950">
                  {unlockedCount} / {badges.length}
                </span>
              </div>
              <div className="px-4 py-2 rounded-xl bg-white border border-amber-300 shadow-sm text-center">
                <span className="text-[10px] text-emerald-700 block">Status Pengembaraan</span>
                <span className="text-lg font-black text-emerald-950">
                  {unlockedCount >= 3 ? 'Mumtaz (Cemerlang)' : 'Sedang Berjaya'}
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-amber-300 flex items-center justify-between text-xs text-emerald-800">
              <div className="text-left">
                <p className="font-bold">Ustaz Cilik AI</p>
                <p className="text-[10px] text-emerald-600">Teman Pengembaraan Sirah</p>
              </div>
              <div className="text-right">
                <p className="font-bold">Pendidikan Islam</p>
                <p className="text-[10px] text-emerald-600">Tahun 3 Sekolah Rendah</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="max-w-5xl mx-auto w-full py-2 text-center text-xs text-emerald-300/60">
        Pendidikan Islam Tahun 3 • Ganjaran Positif &amp; Motivasi Belajar
      </footer>
    </div>
  );
};
