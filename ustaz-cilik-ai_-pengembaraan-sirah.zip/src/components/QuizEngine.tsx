import React, { useState } from 'react';
import { QuizQuestion } from '../logic/sirahData';
import { calculateQuizScore, getQuizFeedback } from '../logic/quizRules';
import { UstazCilikMascot, MascotExpression } from './UstazCilikMascot';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Sparkles,
  Trophy,
  Award,
  ChevronRight,
} from 'lucide-react';

interface QuizEngineProps {
  questions: QuizQuestion[];
  onBack: () => void;
  onQuizComplete: (results: { total: number; correct: number; scorePercent: number; answers: Record<string, number> }) => void;
  onViewAchievements: () => void;
  customMascotUrl?: string | null;
}

export const QuizEngine: React.FC<QuizEngineProps> = ({
  questions,
  onBack,
  onQuizComplete,
  onViewAchievements,
  customMascotUrl,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isSecondTry, setIsSecondTry] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [mascotExp, setMascotExp] = useState<MascotExpression>('welcoming');
  const [feedbackText, setFeedbackText] = useState<string | null>(null);
  const [isFinished, setIsFinished] = useState(false);

  const currentQ = questions[currentIndex];
  const isLastQuestion = currentIndex === questions.length - 1;

  const handleSelectOption = (idx: number) => {
    if (isAnswerChecked) return;
    setSelectedOption(idx);
  };

  const handleCheckAnswer = () => {
    if (selectedOption === null || isAnswerChecked) return;

    const isCorrect = selectedOption === currentQ.correctIndex;
    setIsAnswerChecked(true);

    const feedback = getQuizFeedback(isCorrect, isSecondTry);
    setFeedbackText(feedback.message);
    setMascotExp(feedback.expression);

    if (isCorrect) {
      setUserAnswers((prev) => ({ ...prev, [currentQ.id]: selectedOption }));
      // Letupan confetti comel untuk jawapan betul
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#fbbf24', '#38bdf8'],
      });
    }
  };

  const handleRetryCurrent = () => {
    setIsAnswerChecked(false);
    setSelectedOption(null);
    setIsSecondTry(true);
    setShowHint(true);
    setFeedbackText('Cuba baca semula petunjuk dengan teliti ya adik!');
    setMascotExp('helper');
  };

  const handleNextQuestion = () => {
    if (isLastQuestion) {
      // Selesaikan kuiz
      setIsFinished(true);
      const total = questions.length;
      let correct = 0;
      for (const q of questions) {
        if (userAnswers[q.id] === q.correctIndex) {
          correct += 1;
        }
      }
      const score = calculateQuizScore(total, correct);
      if (score.scorePercent >= 80) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#fbbf24', '#10b981', '#f43f5e', '#38bdf8'],
        });
        setMascotExp('congratulating');
      } else {
        setMascotExp('encouraging');
      }

      onQuizComplete({
        total,
        correct,
        scorePercent: score.scorePercent,
        answers: userAnswers,
      });
    } else {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      setIsSecondTry(false);
      setShowHint(false);
      setFeedbackText(null);
      setMascotExp('welcoming');
    }
  };

  const handleRestartQuiz = () => {
    setCurrentIndex(0);
    setUserAnswers({});
    setSelectedOption(null);
    setIsAnswerChecked(false);
    setIsSecondTry(false);
    setShowHint(false);
    setFeedbackText(null);
    setIsFinished(false);
    setMascotExp('welcoming');
  };

  // Skrin Keputusan Akhir Kuiz
  if (isFinished) {
    const total = questions.length;
    let correct = 0;
    for (const q of questions) {
      if (userAnswers[q.id] === q.correctIndex) {
        correct += 1;
      }
    }
    const score = calculateQuizScore(total, correct);

    return (
      <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between p-4 selection:bg-amber-400 selection:text-emerald-950">
        <header className="max-w-4xl mx-auto w-full flex justify-between items-center py-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm"
          >
            <ArrowLeft className="w-4 h-4 text-amber-300" />
            <span>Kembali ke Portal</span>
          </button>
          <div className="text-amber-300 font-bold text-sm">Keputusan Misi Wahyu Pertama</div>
        </header>

        <main className="max-w-2xl mx-auto w-full my-auto bg-gradient-to-br from-emerald-900/90 to-teal-950/95 border-2 border-amber-400 rounded-3xl p-6 md:p-8 shadow-2xl text-center">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-emerald-950 shadow-xl shadow-amber-500/30 mb-4">
            <Trophy className="w-10 h-10" />
          </div>

          <span className="text-xs font-bold text-amber-300 uppercase tracking-widest">
            Selesai Menjawab!
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-white mt-1 mb-2">
            {score.gradeLabel}
          </h2>

          {/* Paparan Bintang Kejayaan */}
          <div className="flex justify-center items-center gap-2 my-4">
            {[1, 2, 3].map((starIdx) => (
              <span
                key={starIdx}
                className={`text-3xl md:text-4xl transition-transform ${
                  starIdx <= score.stars ? 'text-amber-400 scale-110 drop-shadow-md' : 'text-emerald-800 opacity-40'
                }`}
              >
                ★
              </span>
            ))}
          </div>

          {/* Kad Skor Terperinci */}
          <div className="grid grid-cols-3 gap-3 bg-emerald-950/70 p-4 rounded-2xl border border-emerald-700 my-6">
            <div>
              <p className="text-[11px] text-emerald-300">Jumlah Soalan</p>
              <p className="text-xl font-bold text-white">{total}</p>
            </div>
            <div>
              <p className="text-[11px] text-emerald-300">Jawapan Betul</p>
              <p className="text-xl font-bold text-emerald-400">{correct}</p>
            </div>
            <div>
              <p className="text-[11px] text-emerald-300">Peratusan</p>
              <p className="text-xl font-bold text-amber-400">{score.scorePercent}%</p>
            </div>
          </div>

          {/* Maskot Mengucapkan Tahniah */}
          <div className="my-4 flex justify-center">
            <UstazCilikMascot
              expression={mascotExp}
              size="md"
              bubbleText={
                score.passed
                  ? 'Syabas adik! Adik menunjukkan pemahaman yang sangat membanggakan tentang peristiwa Wahyu Pertama!'
                  : 'Bagus usahanya! Jom baca semula infografik dan cuba lagi ya adik!'
              }
              customImageUrl={customMascotUrl}
            />
          </div>

          {/* Butang Tindakan Selepas Kuiz */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
            <button
              onClick={handleRestartQuiz}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-sm border border-emerald-600 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Cuba Kuiz Sekali Lagi</span>
            </button>

            <button
              onClick={onViewAchievements}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 font-black text-sm shadow-lg shadow-amber-500/30 transition hover:scale-105"
            >
              <Award className="w-4 h-4" />
              <span>Lihat Lencana & Sijil Saya</span>
            </button>
          </div>
        </main>

        <footer className="max-w-4xl mx-auto w-full py-3 text-center text-xs text-emerald-300/60">
          Penilaian Berasaskan Model ASSURE • Pendidikan Islam Tahun 3
        </footer>
      </div>
    );
  }

  // Skrin Menjawab Soalan Kuiz
  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-teal-900 to-stone-900 text-white flex flex-col justify-between p-4 selection:bg-amber-400 selection:text-emerald-950">
      {/* Bar Atas */}
      <header className="max-w-4xl mx-auto w-full flex items-center justify-between py-3 border-b border-emerald-800/60">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 border border-emerald-700/60 font-semibold text-xs md:text-sm"
        >
          <ArrowLeft className="w-4 h-4 text-amber-300" />
          <span>Kembali</span>
        </button>

        {/* Kemajuan Soalan */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-emerald-200">
            Soalan {currentIndex + 1} daripada {questions.length}
          </span>
          <div className="w-24 bg-emerald-900 h-2.5 rounded-full overflow-hidden border border-emerald-700">
            <div
              className="bg-amber-400 h-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>

        <button
          onClick={onViewAchievements}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold"
        >
          <Award className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Lencana</span>
        </button>
      </header>

      {/* Kad Soalan Utama */}
      <main className="max-w-3xl mx-auto w-full my-auto py-6">
        <div className="bg-gradient-to-br from-emerald-900/90 via-teal-900/90 to-emerald-950/95 border-2 border-amber-400/60 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
          {/* Lencana Topik & Jenis */}
          <div className="flex items-center justify-between mb-4">
            <span className="px-3 py-1 rounded-full bg-emerald-800 border border-emerald-600 text-amber-300 text-xs font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{currentQ.topic}</span>
            </span>

            {/* Butang Petunjuk */}
            <button
              onClick={() => setShowHint((prev) => !prev)}
              className="flex items-center gap-1 text-xs text-amber-300 hover:text-amber-200 font-semibold underline underline-offset-4"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{showHint ? 'Tutup Petunjuk' : 'Perlukan Petunjuk?'}</span>
            </button>
          </div>

          {/* Kotak Petunjuk jika dibuka */}
          {showHint && (
            <div className="bg-amber-400/15 border border-amber-400/40 rounded-2xl p-3.5 mb-4 text-xs md:text-sm text-amber-200 flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0 mt-0.5" />
              <p>
                <strong>Petunjuk Ustaz Cilik:</strong> {currentQ.hint}
              </p>
            </div>
          )}

          {/* Teks Soalan */}
          <h3 className="text-lg md:text-2xl font-black text-white mb-6 leading-relaxed">
            {currentQ.question}
          </h3>

          {/* Pilihan Jawapan */}
          <div className="space-y-3 mb-6">
            {currentQ.options.map((opt, oIdx) => {
              const isSelected = selectedOption === oIdx;
              const isCorrectAnswer = oIdx === currentQ.correctIndex;

              let btnStyle = 'bg-emerald-950/60 border-emerald-700 text-white hover:bg-emerald-800/80';
              if (isAnswerChecked) {
                if (isCorrectAnswer) {
                  btnStyle = 'bg-emerald-600 border-emerald-400 text-white font-bold ring-2 ring-emerald-300';
                } else if (isSelected && !isCorrectAnswer) {
                  btnStyle = 'bg-rose-900/80 border-rose-500 text-rose-100 font-bold';
                }
              } else if (isSelected) {
                btnStyle = 'bg-gradient-to-r from-amber-400 to-yellow-500 text-emerald-950 font-bold border-amber-300 shadow-lg';
              }

              return (
                <button
                  key={oIdx}
                  onClick={() => handleSelectOption(oIdx)}
                  disabled={isAnswerChecked}
                  className={`w-full text-left p-4 rounded-2xl border-2 transition-all duration-200 flex items-center justify-between gap-3 text-sm md:text-base ${btnStyle}`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                        isSelected && !isAnswerChecked
                          ? 'bg-emerald-950 text-amber-300'
                          : 'bg-emerald-800 text-emerald-200 border border-emerald-600'
                      }`}
                    >
                      {String.fromCharCode(65 + oIdx)}
                    </span>
                    <span>{opt}</span>
                  </div>

                  {/* Ikon Semakan Jawapan */}
                  {isAnswerChecked && isCorrectAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-200 flex-shrink-0" />
                  )}
                  {isAnswerChecked && isSelected && !isCorrectAnswer && (
                    <XCircle className="w-5 h-5 text-rose-300 flex-shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Kotak Maklum Balas Positif selepas Disemak */}
          {isAnswerChecked && (
            <div
              className={`p-4 rounded-2xl border mb-6 text-xs md:text-sm leading-relaxed ${
                selectedOption === currentQ.correctIndex
                  ? 'bg-emerald-900/80 border-emerald-400 text-emerald-100'
                  : 'bg-amber-950/80 border-amber-500 text-amber-100'
              }`}
            >
              <p className="font-bold mb-1">{feedbackText}</p>
              <p className="opacity-90">{currentQ.explanation}</p>
            </div>
          )}

          {/* Butang Kawalan Soalan Bawah */}
          <div className="flex items-center justify-between pt-4 border-t border-emerald-800/60">
            <div>
              {isAnswerChecked && selectedOption !== currentQ.correctIndex && (
                <button
                  onClick={handleRetryCurrent}
                  className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/50 text-xs font-bold transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Cuba Lagi Soalan Ini</span>
                </button>
              )}
            </div>

            {!isAnswerChecked ? (
              <button
                onClick={handleCheckAnswer}
                disabled={selectedOption === null}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 disabled:opacity-40 text-emerald-950 font-black text-sm shadow-lg shadow-amber-500/20 transition hover:scale-105 active:scale-95"
              >
                Semak Jawapan
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-black text-sm shadow-lg shadow-emerald-500/30 transition hover:scale-105 active:scale-95 flex items-center gap-2"
              >
                <span>{isLastQuestion ? 'Lihat Keputusan Kuiz' : 'Soalan Seterusnya'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </main>

      <footer className="max-w-4xl mx-auto w-full py-2 text-center text-xs text-emerald-300/60">
        Pendidikan Islam Tahun 3 • Kuiz Interaktif Sirah
      </footer>
    </div>
  );
};
