/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  INITIAL_OBJECTIVES,
  INITIAL_INFOGRAPHIC,
  INITIAL_QUIZ_QUESTIONS,
  INITIAL_BADGES,
  LearningObjective,
  InfographicSection,
  QuizQuestion,
  Badge,
} from './logic/sirahData';
import {
  evaluateObjectiveMastery,
  evaluateBadges,
  ObjectiveMastery,
  PlayerMilestones,
} from './logic/quizRules';
import { speechService } from './utils/speech';

// Komponen
import { HeroOpening } from './components/HeroOpening';
import { SirahMap } from './components/SirahMap';
import { GuaHiraPortal } from './components/GuaHiraPortal';
import { InfographicViewer } from './components/InfographicViewer';
import { ChatWindow } from './components/ChatWindow';
import { QuizEngine } from './components/QuizEngine';
import { AchievementSystem } from './components/AchievementSystem';
import { TeacherPanel } from './components/TeacherPanel';
import { PresentationMode } from './components/PresentationMode';
import { HowToPlayModal } from './components/HowToPlayModal';

type AppView =
  | 'hero'
  | 'map'
  | 'portal-gua-hira'
  | 'infographic'
  | 'chat'
  | 'quiz'
  | 'achievements'
  | 'teacher';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('hero');
  const [isPresentationMode, setIsPresentationMode] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  // Kandungan Sirah & Pedagogi ASSURE
  const [objectives, setObjectives] = useState<LearningObjective[]>(INITIAL_OBJECTIVES);
  const [infographicSections, setInfographicSections] = useState<InfographicSection[]>(INITIAL_INFOGRAPHIC);
  const [readSectionIds, setReadSectionIds] = useState<string[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(INITIAL_QUIZ_QUESTIONS);
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);
  const [masteryMap, setMasteryMap] = useState<Record<string, ObjectiveMastery>>({});

  // Statistik Murid untuk Pembukaan Lencana
  const [hasExploredPortal, setHasExploredPortal] = useState(false);
  const [quizCorrectCount, setQuizCorrectCount] = useState(0);
  const [quizScorePercent, setQuizScorePercent] = useState(0);
  const [askedQuestionsCount, setAskedQuestionsCount] = useState(0);

  // Soalan awalan untuk dihantar terus ke chatbot
  const [chatPrefillQuestion, setChatPrefillQuestion] = useState<string>('');

  // Imej Tersuai Guru
  const [customInfographicUrl, setCustomInfographicUrl] = useState<string | null>(null);
  const [customMascotUrl, setCustomMascotUrl] = useState<string | null>(null);

  // Sokongan autostart mengikut piawaian Ultra Mode (?autostart=1)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') {
        setCurrentView('portal-gua-hira');
        setHasExploredPortal(true);
      }
    }
  }, []);

  // Kemas kini pembukaan lencana secara automatik apabila pencapaian dipenuhi
  useEffect(() => {
    const milestones: PlayerMilestones = {
      hasExploredPortal,
      readSectionsCount: readSectionIds.length,
      totalSectionsCount: infographicSections.length,
      quizCorrectCount,
      quizScorePercent,
      askedQuestionsCount,
    };

    const { updatedBadges, newlyUnlocked } = evaluateBadges(badges, milestones);
    if (newlyUnlocked.length > 0) {
      setBadges(updatedBadges);
    }
  }, [
    hasExploredPortal,
    readSectionIds,
    quizCorrectCount,
    quizScorePercent,
    askedQuestionsCount,
    infographicSections.length,
  ]);

  // Pengendali Audio Bersuara
  const handleToggleAudio = () => {
    if (speechService.isSpeaking()) {
      speechService.stop();
      setIsAudioMuted(true);
    } else {
      setIsAudioMuted((prev) => !prev);
    }
  };

  // Navigasi ke Portal Gua Hira'
  const handleGoToGuaHira = () => {
    speechService.stop();
    setHasExploredPortal(true);
    setCurrentView('portal-gua-hira');
  };

  // Navigasi ke Chatbot dengan soalan terpilih
  const handleAskQuestionFromContext = (topic: string, question: string) => {
    speechService.stop();
    setChatPrefillQuestion(question);
    setCurrentView('chat');
  };

  // Pengendali Bahagian Infografik Dibaca
  const handleSectionRead = (sectionId: string) => {
    if (!readSectionIds.includes(sectionId)) {
      setReadSectionIds((prev) => [...prev, sectionId]);
    }
  };

  // Pengendali Selesai Kuiz
  const handleQuizComplete = (results: {
    total: number;
    correct: number;
    scorePercent: number;
    answers: Record<string, number>;
  }) => {
    setQuizCorrectCount(results.correct);
    setQuizScorePercent(results.scorePercent);

    // Nilai tahap penguasaan objektif (ASSURE)
    const evaluatedMastery = evaluateObjectiveMastery(quizQuestions, results.answers);
    setMasteryMap(evaluatedMastery);

    // Kemas kini status objektif
    setObjectives((prev) =>
      prev.map((obj) => {
        const m = evaluatedMastery[obj.id];
        if (m && m.isMastered) {
          return { ...obj, status: 'dikuasai' };
        } else if (m && m.correctQuestions > 0) {
          return { ...obj, status: 'sedang_belajar' };
        }
        return obj;
      })
    );
  };

  // Set semula sesi bilik darjah
  const handleResetSession = () => {
    setReadSectionIds([]);
    setQuizCorrectCount(0);
    setQuizScorePercent(0);
    setAskedQuestionsCount(0);
    setHasExploredPortal(false);
    setMasteryMap({});
    setBadges(INITIAL_BADGES);
    setObjectives(INITIAL_OBJECTIVES);
    setCurrentView('hero');
  };

  const completedObjectivesCount = Object.values(masteryMap).filter((m) => m.isMastered).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased">
      {/* 1. Mod Pembentangan Projektor 16:9 */}
      {isPresentationMode && (
        <PresentationMode
          sections={infographicSections}
          onExit={() => setIsPresentationMode(false)}
          onOpenChat={() => {
            setIsPresentationMode(false);
            setCurrentView('chat');
          }}
          onOpenQuiz={() => {
            setIsPresentationMode(false);
            setCurrentView('quiz');
          }}
          onOpenMap={() => {
            setIsPresentationMode(false);
            setCurrentView('map');
          }}
          customMascotUrl={customMascotUrl}
        />
      )}

      {/* 2. Paparan Mengikut Pandangan Semasa (CurrentView) */}
      {!isPresentationMode && (
        <>
          {currentView === 'hero' && (
            <HeroOpening
              onStartAdventure={handleGoToGuaHira}
              onAskQuestion={() => {
                setChatPrefillQuestion('');
                setCurrentView('chat');
              }}
              onHowToPlay={() => setShowHowToPlay(true)}
              onTogglePresentation={() => setIsPresentationMode(true)}
              onOpenTeacherPanel={() => setCurrentView('teacher')}
              isAudioMuted={isAudioMuted}
              onToggleAudio={handleToggleAudio}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'map' && (
            <SirahMap
              onBackToHome={() => setCurrentView('hero')}
              onEnterGuaHira={handleGoToGuaHira}
              onAskTopicQuestion={handleAskQuestionFromContext}
              onViewAchievements={() => setCurrentView('achievements')}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'portal-gua-hira' && (
            <GuaHiraPortal
              onLearnInfographic={() => setCurrentView('infographic')}
              onAskChatbot={() => {
                setChatPrefillQuestion('');
                setCurrentView('chat');
              }}
              onStartQuiz={() => setCurrentView('quiz')}
              onBackToMap={() => setCurrentView('map')}
              onViewAchievements={() => setCurrentView('achievements')}
              completedObjectivesCount={completedObjectivesCount}
              totalObjectivesCount={objectives.length}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'infographic' && (
            <InfographicViewer
              sections={infographicSections}
              onBack={() => setCurrentView('portal-gua-hira')}
              onAskAboutSection={handleAskQuestionFromContext}
              onTakeQuiz={() => setCurrentView('quiz')}
              onSectionRead={handleSectionRead}
              readSectionIds={readSectionIds}
              customInfographicUrl={customInfographicUrl}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'chat' && (
            <ChatWindow
              onBack={() => setCurrentView('portal-gua-hira')}
              onQuestionAsked={() => setAskedQuestionsCount((prev) => prev + 1)}
              onOpenInfographic={() => setCurrentView('infographic')}
              initialQuestion={chatPrefillQuestion}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'quiz' && (
            <QuizEngine
              questions={quizQuestions}
              onBack={() => setCurrentView('portal-gua-hira')}
              onQuizComplete={handleQuizComplete}
              onViewAchievements={() => setCurrentView('achievements')}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'achievements' && (
            <AchievementSystem
              badges={badges}
              onBack={() => setCurrentView('portal-gua-hira')}
              customMascotUrl={customMascotUrl}
            />
          )}

          {currentView === 'teacher' && (
            <TeacherPanel
              onBack={() => setCurrentView('hero')}
              objectives={objectives}
              masteryMap={masteryMap}
              infographicSections={infographicSections}
              onUpdateInfographic={setInfographicSections}
              quizQuestions={quizQuestions}
              onUpdateQuizQuestions={setQuizQuestions}
              customInfographicUrl={customInfographicUrl}
              onSetCustomInfographicUrl={setCustomInfographicUrl}
              customMascotUrl={customMascotUrl}
              onSetCustomMascotUrl={setCustomMascotUrl}
              onResetSession={handleResetSession}
            />
          )}

          {/* Modal Cara Bermain */}
          {showHowToPlay && (
            <HowToPlayModal
              onClose={() => setShowHowToPlay(false)}
              onStart={handleGoToGuaHira}
            />
          )}
        </>
      )}
    </div>
  );
}
